/* ============================================================
   Hopply Web — Task add / edit modal
   ============================================================ */
const { AIRCRAFT: TE_AC } = window.HOPPLY;

const TE_TABS = ['Identity', 'Details', 'Schedule', 'Overrides'];
const CATS = ['Airframe', 'Engine', 'Propeller', 'Avionics', 'Unknown'];

function TaskEditModal({ payload, onClose }) {
  const editing = payload.mode === 'edit';
  const t = payload.task || {};
  const ac = TE_AC.find(a => a.id === payload.aircraftId);
  const [tab, setTab] = useState('Identity');
  const [name, setName] = useState(t.name || '');
  const [cat, setCat] = useState((t.cat ? t.cat[0] + t.cat.slice(1).toLowerCase() : 'Airframe'));
  const [oneTime, setOneTime] = useState(false);
  const [months, setMonths] = useState(t.dueType === 'date' ? '12' : '');
  const [hours, setHours] = useState(t.dueType === 'hrs' ? '100' : '');

  const tabsEl = (
    <div className="modal-tabs">
      {TE_TABS.map(x => (
        <button key={x} className={`tab ${tab === x ? 'active' : ''}`} onClick={() => setTab(x)} style={{ fontSize: 14 }}>{x}</button>
      ))}
    </div>
  );

  const footer = (
    <>
      <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
      {editing && <button className="btn btn-danger-ghost"><Icon name="trash" size={16} /> Delete</button>}
      <div style={{ flex: 1 }} />
      <button className="btn btn-primary" onClick={onClose}><Icon name="check" size={16} stroke={2.4} /> {editing ? 'Save changes' : 'Create task'}</button>
    </>
  );

  return (
    <Modal title={editing ? 'Update task' : 'New maintenance task'} onClose={onClose} tabs={tabsEl} footer={footer}>
      <div className="muted" style={{ fontSize: 12.5, marginBottom: 18, marginTop: -4 }}>
        For <span className="mono" style={{ color: 'var(--tail)', fontWeight: 700 }}>{ac?.tail}</span> · {ac?.name}
      </div>

      {tab === 'Identity' && (
        <div>
          <div className="field">
            <label className="field-l">Task name</label>
            <input className="input" placeholder="e.g. 100 Hour Inspection" value={name} onChange={e => setName(e.target.value)} />
          </div>
          <div className="field">
            <label className="field-l">Category</label>
            <div className="flex g8" style={{ flexWrap: 'wrap' }}>
              {CATS.map(c => (
                <button key={c} className={`chip ${cat === c ? 'active' : ''}`} style={{ height: 38 }} onClick={() => setCat(c)}>
                  {cat === c && <Icon name="check" size={13} stroke={2.4} />}{c}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {tab === 'Details' && (
        <div>
          <div className="field">
            <label className="field-l">Component</label>
            <input className="input" placeholder="e.g. Lycoming IO-360" defaultValue={t.cat ? '' : ''} />
          </div>
          <div className="field">
            <label className="field-l">Description / notes</label>
            <textarea className="input" placeholder="What this task covers, references, SB / AD numbers…" />
          </div>
          <div className="field">
            <label className="field-l">Reference</label>
            <input className="input" placeholder="SB-2024-11, AD 2023-05-09…" />
          </div>
        </div>
      )}

      {tab === 'Schedule' && (
        <div>
          <div className="toggle-row" style={{ borderBottom: '1px solid var(--outline-variant)', paddingBottom: 16 }}>
            <div>
              <div className="set-t">One-time task</div>
              <div className="set-s">Moves to history after the first log</div>
            </div>
            <Toggle on={oneTime} onClick={() => setOneTime(o => !o)} />
          </div>

          {!oneTime && (
            <div style={{ marginTop: 20 }}>
              <div className="field-l" style={{ marginBottom: 10 }}>Recurring interval</div>
              <div className="row-2">
                <div>
                  <input className="input" placeholder="12" value={months} onChange={e => setMonths(e.target.value)} />
                  <div className="field-hint">Months</div>
                </div>
                <span className="or-chip">OR</span>
                <div>
                  <input className="input" placeholder="100" value={hours} onChange={e => setHours(e.target.value)} />
                  <div className="field-hint">Engine hours</div>
                </div>
              </div>
              <div className="flex ac g8" style={{ marginTop: 14, color: 'var(--primary)', fontSize: 12.5, fontWeight: 600 }}>
                <Icon name="clock" size={14} /> Due on whichever comes first.
              </div>

              <div className="field-l" style={{ margin: '24px 0 8px' }}>Schedule with another task <span className="faint" style={{ fontWeight: 400, textTransform: 'none', letterSpacing: 0 }}>(optional)</span></div>
              <div className="muted" style={{ fontSize: 12.5, marginBottom: 12 }}>This task becomes due whenever the selected task is next due.</div>
              <button className="btn btn-ghost" style={{ width: '100%', borderStyle: 'dashed' }}><Icon name="link" size={16} /> Link to maintenance task</button>
            </div>
          )}
        </div>
      )}

      {tab === 'Overrides' && (
        <div>
          <div className="muted" style={{ fontSize: 13, marginBottom: 18, lineHeight: 1.5 }}>
            Override the computed schedule when the airframe history doesn't match the default interval math.
          </div>
          <div className="field">
            <label className="field-l">Last completed at (engine hrs)</label>
            <input className="input mono" placeholder={ac?.engineHrs} />
          </div>
          <div className="field">
            <label className="field-l">Last completed date</label>
            <input className="input" type="date" />
          </div>
          <div className="field" style={{ marginBottom: 0 }}>
            <label className="field-l">Manual next-due override</label>
            <input className="input mono" placeholder="Leave blank to auto-calculate" />
            <div className="field-hint">Takes priority over interval math until the next log is filed.</div>
          </div>
        </div>
      )}
    </Modal>
  );
}

Object.assign(window, { TaskEditModal });
