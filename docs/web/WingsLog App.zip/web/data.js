/* ============================================================
   Hopply Web — data layer
   Individual owner, 3 aircraft. Exposed on window.HOPPLY
   ============================================================ */
(function () {

  const AIRCRAFT = [
    {
      id: 'n123aa',
      name: 'Cessna 172SP',
      tail: 'N123AA',
      type: 'Single-engine piston',
      engine: 'Lycoming IO-360-L2A',
      status: 'warn',                 // ok | warn | over
      engineHrs: '1243.5',
      airframeHrs: '1243.5',
      propHrs: '900.0',
      tach: '1243.5',
      nextDue: { task: '100 Hour Inspection', when: 'in 6.5 hrs', kind: 'warn' },
      dueCount: 4, overdueCount: 0,
    },
    {
      id: 'n2098u',
      name: 'SoroSuub N-1 Scout',
      tail: 'N2098U',
      type: 'Experimental · LSA',
      engine: 'Rotax 915 iSa',
      status: 'over',
      engineHrs: '512.0',
      airframeHrs: '512.0',
      propHrs: '512.0',
      tach: '512.0',
      nextDue: { task: 'Oil change', when: 'overdue 12 hrs', kind: 'over' },
      dueCount: 3, overdueCount: 1,
    },
    {
      id: 'n532sl',
      name: 'Sling TSi',
      tail: 'N532SL',
      type: 'Experimental · 4-seat',
      engine: 'Rotax 915 iS',
      status: 'ok',
      engineHrs: '305.2',
      airframeHrs: '305.2',
      propHrs: '305.2',
      tach: '305.2',
      nextDue: { task: 'Annual Inspection', when: 'in 4 months', kind: 'ok' },
      dueCount: 2, overdueCount: 0,
    },
  ];

  // tasks keyed by aircraft id
  const TASKS = {
    n123aa: {
      due: [
        { id:'t1', name:'100 Hour Inspection', kind:'warn', dueType:'hrs', dueValue:'1250.0', remaining:'6.5 hrs', metric:'Next due tach', interval:'Every 100 hrs', cat:'AIRFRAME' },
        { id:'t2', name:'ELT Battery Check', kind:'ok', dueType:'date', dueValue:'04/11/2027', remaining:'11 months', metric:'Deadline', interval:'Every 12 months', cat:'AVIONICS' },
        { id:'t3', name:'Transponder / Pitot-Static', kind:'ok', dueType:'date', dueValue:'09/30/2027', remaining:'16 months', metric:'Deadline', interval:'Every 24 months', cat:'AVIONICS' },
        { id:'t4', name:'Oil & Filter Change', kind:'warn', dueType:'hrs', dueValue:'1293.5', remaining:'50 hrs', metric:'Next due engine', interval:'Every 50 hrs', cat:'ENGINE' },
      ],
      history: [
        { id:'h1', name:'Annual Inspection', kind:'done', dueValue:'06/02/2025', metric:'Completed', cat:'AIRFRAME' },
      ],
    },
    n2098u: {
      due: [
        { id:'t5', name:'Oil change', kind:'over', dueType:'hrs', dueValue:'500.0', remaining:'overdue 12 hrs', metric:'Next due engine', interval:'Every 50 hrs', cat:'ENGINE' },
        { id:'t6', name:'Gearbox Inspection', kind:'warn', dueType:'hrs', dueValue:'600.0', remaining:'88 hrs', metric:'Next due engine', interval:'Every 100 hrs', cat:'ENGINE' },
        { id:'t7', name:'Rubber Hose Replacement', kind:'ok', dueType:'date', dueValue:'01/15/2028', remaining:'19 months', metric:'Deadline', interval:'Every 5 years', cat:'AIRFRAME' },
      ],
      history: [],
    },
    n532sl: {
      due: [
        { id:'t8', name:'Annual Inspection', kind:'ok', dueType:'date', dueValue:'09/29/2026', remaining:'4 months', metric:'Deadline', interval:'Every 12 months', cat:'AIRFRAME' },
        { id:'t9', name:'Spark Plug Service', kind:'ok', dueType:'hrs', dueValue:'400.0', remaining:'95 hrs', metric:'Next due engine', interval:'Every 100 hrs', cat:'ENGINE' },
      ],
      history: [],
    },
  };

  // logs keyed by aircraft id
  const LOGS = {
    n123aa: [
      { id:'l1', type:'ENGINE',    date:'04/14/2026', tach:'1243.5', engineTime:'1243.5', airframeTime:'1243.5', propTime:'900.0', component:'Lycoming IO-360', desc:'Replaced the turbocharger check valve and associated gaskets. Torqued to spec per SB-2024-11.', tech:'R. Morales', tasks:['100 Hour Inspection','Turbo Valve Replacement'] },
      { id:'l2', type:'AIRFRAME',  date:'06/02/2025', tach:'1198.2', engineTime:'1198.2', airframeTime:'1198.2', propTime:'855.0', component:'Airframe', desc:'Annual inspection completed. All items within limits. Logbook signed off.', tech:'J. Hartley', tasks:['Annual Inspection','Rubber Replacement'] },
      { id:'l3', type:'AVIONICS',  date:'03/18/2025', tach:'1151.0', engineTime:'1151.0', airframeTime:'1151.0', propTime:'808.0', component:'G1000 NXi', desc:'Updated G1000 software to v19.2. Tested transponder output, 200W confirmed.', tech:'R. Morales', tasks:[] },
      { id:'l4', type:'ENGINE',    date:'01/05/2025', tach:'1089.5', engineTime:'1089.5', airframeTime:'1089.5', propTime:'746.5', component:'Lycoming IO-360', desc:'Spark plugs replaced. All gaps checked to 0.016". Compression test passed.', tech:'J. Hartley', tasks:['Spark Plug Replacement'] },
      { id:'l5', type:'PROPELLER', date:'10/22/2024', tach:'1042.0', engineTime:'1042.0', airframeTime:'1042.0', propTime:'699.0', component:'McCauley 2-blade', desc:'Prop strike inspection. No damage found. Rebalanced to within 0.2 IPS.', tech:'R. Morales', tasks:[] },
    ],
    n2098u: [
      { id:'l6', type:'ENGINE',    date:'05/01/2026', tach:'500.0', engineTime:'500.0', airframeTime:'500.0', propTime:'500.0', component:'Rotax 915 iSa', desc:'Oil analysis sample taken. Minor metal content within limits. Scheduled gearbox inspection.', tech:'R. Morales', tasks:['Gearbox Inspection'] },
      { id:'l7', type:'AVIONICS',  date:'02/12/2026', tach:'450.0', engineTime:'450.0', airframeTime:'450.0', propTime:'450.0', component:'Garmin G3X', desc:'Firmware updated to 9.10. ADS-B out verified with FAA PAPR report.', tech:'A. Okafor', tasks:[] },
    ],
    n532sl: [
      { id:'l8', type:'AIRFRAME',  date:'04/02/2026', tach:'305.2', engineTime:'305.2', airframeTime:'305.2', propTime:'305.2', component:'Airframe', desc:'Condition inspection signed off. Control surfaces re-tensioned to spec.', tech:'J. Hartley', tasks:['Annual Inspection'] },
      { id:'l9', type:'PROPELLER', date:'11/20/2025', tach:'260.0', engineTime:'260.0', airframeTime:'260.0', propTime:'260.0', component:'Airmaster CS', desc:'Constant-speed prop governor serviced. Pitch range checked.', tech:'A. Okafor', tasks:[] },
    ],
  };

  const FILTER_TYPES = ['Airframe','Engine','Propeller'];

  // squawks (pilot-reported defects) keyed by aircraft id
  // severity: grounding | monitor | minor   ·   status: open | deferred | resolved
  const SQUAWKS = {
    n123aa: [
      { id:'sq1', title:'#2 cylinder CHT reads ~20°F high in cruise', severity:'monitor', status:'open',
        desc:'Noticed during the KPAO→KSQL hop. CHT settles ~400°F in level cruise, others sit near 380°F. Baffling looks intact on walkaround.',
        system:'ENGINE', reportedBy:'Fan Zhang', date:'04/20/2026', flight:'KPAO → KSQL', resolvedDate:null, resolvedLog:null },
      { id:'sq2', title:'Landing light flickers on rollout', severity:'minor', status:'deferred',
        desc:'Intermittent flicker after touchdown, suspect a loose ground or the bulb itself. Not required day VFR — deferred to next squawk-day.',
        system:'AVIONICS', reportedBy:'Fan Zhang', date:'04/02/2026', flight:'Pattern work', resolvedDate:null, resolvedLog:null },
      { id:'sq3', title:'Cabin door seal whistles above 110 kt', severity:'minor', status:'resolved',
        desc:'Air noise from the upper door latch at cruise. Reseated the seal and adjusted the latch cam.',
        system:'AIRFRAME', reportedBy:'Fan Zhang', date:'02/28/2026', flight:'KSQL → KMRY', resolvedDate:'03/05/2026', resolvedLog:'Annual Inspection' },
    ],
    n2098u: [
      { id:'sq4', title:'Right brake feels soft, pedal travels far', severity:'grounding', status:'open',
        desc:'Right main brake spongy on the last two taxis, pedal goes nearly to the floor before bite. Treating as no-go until bled and inspected.',
        system:'AIRFRAME', reportedBy:'Fan Zhang', date:'05/04/2026', flight:'Taxi test', resolvedDate:null, resolvedLog:null },
      { id:'sq5', title:'Oil temp slow to reach green in cold OAT', severity:'monitor', status:'open',
        desc:'Below ~5°C OAT the oil temp takes 12+ min to enter the green arc. Watching — may need a winterization plate.',
        system:'ENGINE', reportedBy:'Fan Zhang', date:'04/18/2026', flight:'KTRK → KRNO', resolvedDate:null, resolvedLog:null },
    ],
    n532sl: [],
  };

  const SQUAWK_SYSTEMS = ['Airframe','Engine','Propeller','Avionics','Electrical','Cabin'];

  const USER = { name:'Fan Zhang', email:'fanzhang172@gmail.com',
    cert:'Private Pilot · ASEL', certNo:'3947201', medical:'Class 3', medicalExp:'08/2027' };

  // ---- icons (stroke uses currentColor) ----
  const I = {
    dashboard:'<path d="M3 3h7v8H3V3zm0 10h7v8H3v-8zm10-10h8v5h-8V3zm0 7h8v11h-8V10z"/>',
    logs:'<path d="M4 4h13l3 3v13H4V4z"/><path d="M9 9h7M9 13h7M9 17h4"/>',
    tasks:'<path d="M9 11l2 2 4-4"/><rect x="3" y="4" width="18" height="16" rx="2"/>',
    export:'<path d="M12 15V3m0 0L8 7m4-4l4 4"/><path d="M4 13v6a1 1 0 001 1h14a1 1 0 001-1v-6"/>',
    settings:'<circle cx="12" cy="12" r="3.2"/><path d="M19.4 13a1.65 1.65 0 00.33 1.82l.05.05a2 2 0 11-2.83 2.83l-.05-.05a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 11-4 0v-.08a1.65 1.65 0 00-1.08-1.51 1.65 1.65 0 00-1.82.33l-.05.05a2 2 0 11-2.83-2.83l.05-.05A1.65 1.65 0 005 13.18a1.65 1.65 0 00-1.51-1H3a2 2 0 110-4h.08A1.65 1.65 0 004.6 7.1a1.65 1.65 0 00-.33-1.82l-.05-.05A2 2 0 116.95 2.4l.05.05a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 114 0v.08a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.05-.05a2 2 0 112.83 2.83l-.05.05A1.65 1.65 0 0019.4 9v.18z"/>',
    plane:'<path d="M21 16v-2l-8-5V3.5a1.5 1.5 0 00-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5L21 16z"/>',
    chevR:'<path d="M9 6l6 6-6 6"/>',
    chevL:'<path d="M15 6l-6 6 6 6"/>',
    search:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
    filter:'<path d="M3 5h18M6 12h12M10 19h4"/>',
    plus:'<path d="M12 5v14M5 12h14"/>',
    bell:'<path d="M18 8a6 6 0 00-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 01-3.4 0"/>',
    sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon:'<path d="M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z"/>',
    edit:'<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4 12.5-12.5z"/>',
    cal:'<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    wrench:'<path d="M14.7 6.3a4 4 0 00-5.4 5l-6 6 2.4 2.4 6-6a4 4 0 005-5.4l-2.7 2.7-2.1-.6-.6-2.1 2.7-2.7z"/>',
    gauge:'<path d="M12 14l4-4"/><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/>',
    history:'<path d="M3 12a9 9 0 109-9 9 9 0 00-7 3.3M3 3v4h4"/><path d="M12 8v4l3 2"/>',
    pdf:'<path d="M14 3H6v18h12V7l-4-4z"/><path d="M14 3v4h4"/><path d="M8 13h1.5a1.5 1.5 0 010 3H8v-3zm0 0v5"/>',
    csv:'<path d="M14 3H6v18h12V7l-4-4z"/><path d="M14 3v4h4"/><path d="M9 13v5M9 13h6M9 15.5h5"/>',
    xlsx:'<path d="M14 3H6v18h12V7l-4-4z"/><path d="M14 3v4h4"/><path d="M9 13l4 5M13 13l-4 5"/>',
    zip:'<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M11 3v2M13 5v2M11 7v2M13 9v2M11 11v2.5h2V11"/>',
    check:'<path d="M4 12l5 5L20 6"/>',
    x:'<path d="M6 6l12 12M18 6L6 18"/>',
    arrowR:'<path d="M5 12h14M13 6l6 6-6 6"/>',
    trash:'<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/>',
    link:'<path d="M10 13a5 5 0 007 0l3-3a5 5 0 00-7-7l-1.5 1.5"/><path d="M14 11a5 5 0 00-7 0l-3 3a5 5 0 007 7l1.5-1.5"/>',
    doc:'<path d="M14 3H6v18h12V7l-4-4z"/><path d="M14 3v4h4M9 13h6M9 17h6"/>',
    user:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/>',
    units:'<path d="M3 7h18M3 7l3-3M3 7l3 3M21 17H3M21 17l-3-3M21 17l-3 3"/>',
    shield:'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z"/>',
    logout:'<path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/>',
    squawk:'<path d="M10.3 4.3L2 19a1.5 1.5 0 001.3 2.2h17.4A1.5 1.5 0 0022 19L13.7 4.3a1.5 1.5 0 00-2.6 0z"/><path d="M12 9v5M12 17.5v.5"/>',
    flag:'<path d="M4 21V4M4 4h12l-2 4 2 4H4"/>',
    checkCircle:'<circle cx="12" cy="12" r="9"/><path d="M8.5 12.5l2.5 2.5 4.5-5"/>',
    pause:'<rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/>',
  };

  window.HOPPLY = { AIRCRAFT, TASKS, LOGS, SQUAWKS, FILTER_TYPES, SQUAWK_SYSTEMS, USER, I };
})();
