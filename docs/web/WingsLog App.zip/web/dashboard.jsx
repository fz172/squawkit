/* ============================================================
   Hopply Web — per-aircraft Dashboard
   ============================================================ */
const { TASKS: DASH_TASKS, SQUAWKS: DASH_SQ } = window.HOPPLY;

function CraftHero({ aircraft, go, openTaskEdit }) {
  return (
    <div className="craft-hero">
      <div className="craft-hero-img"><Icon name="plane" size={42} fill /></div>
      <div className="craft-hero-main">
        <div className="flex ac g12" style={{ flexWrap: 'wrap' }}>
          <div className="craft-hero-name">{aircraft.name}</div>
          <StatusPill kind={aircraft.status} />
        </div>
        <div className="craft-hero-row">
          <span className="craft-hero-tail">{aircraft.tail}</span>
          <span className="muted" style={{ fontSize: 13 }}>·</span>
          <span className="muted" style={{ fontSize: 13.5 }}>{aircraft.type}</span>
          <span className="muted" style={{ fontSize: 13 }}>·</span>
          <span className="muted" style={{ fontSize: 13.5 }}>{aircraft.engine}</span>
        </div>
        <div className="craft-hero-stats">
          <div><div className="chs-n mono">{aircraft.engineHrs}</div><div className="chs-l">Engine hrs</div></div>
          <div><div className="chs-n mono">{aircraft.airframeHrs}</div><div className="chs-l">Airframe hrs</div></div>
          <div><div className="chs-n mono">{aircraft.propHrs}</div><div className="chs-l">Propeller hrs</div></div>
          <div><div className="chs-n mono">{aircraft.tach}</div><div className="chs-l">Tach</div></div>
        </div>
      </div>
      <div className="craft-hero-actions hide-mobile">
        <button className="btn btn-primary" onClick={() => go({ kind: 'aircraft', section: 'logs' })}><Icon name="plus" size={16} stroke={2.2} /> Add log</button>
        <button className="btn btn-ghost" onClick={() => openTaskEdit({ mode: 'add', aircraftId: aircraft.id })}>New task</button>
      </div>
    </div>
  );
}

function StatTile({ kind, icon, n, label, danger, onClick }) {
  return (
    <button className="stat" onClick={onClick} style={{ textAlign: 'left', cursor: 'pointer' }}>
      <div className="stat-top">
        <div className={`stat-ico ${kind}`}><Icon name={icon} size={18} stroke={icon === 'check' ? 2.4 : 1.8} /></div>
        <Icon name="arrowR" size={16} style={{ color: 'var(--on-faint)' }} />
      </div>
      <div><div className="stat-n" style={{ color: danger && n > 0 ? 'var(--error)' : 'inherit' }}>{n}</div><div className="stat-l">{label}</div></div>
    </button>
  );
}

function AircraftDashboard({ aircraft, go, openTaskEdit }) {
  const due = DASH_TASKS[aircraft.id]?.due || [];
  const overdue = due.filter((t) => t.kind === 'over').length;
  const dueSoon = due.filter((t) => t.kind === 'warn').length;
  const openSq = (DASH_SQ[aircraft.id] || []).filter((s) => s.status === 'open').length;

  return (
    <div className="page">
      <CraftHero aircraft={aircraft} go={go} openTaskEdit={openTaskEdit} />

      <div className="stat-row" style={{ marginBottom: 24 }}>
        <StatTile kind="over" icon="wrench" n={overdue} label="Overdue tasks" danger onClick={() => go({ kind: 'aircraft', section: 'tasks' })} />
        <StatTile kind="warn" icon="clock" n={dueSoon} label="Due soon" onClick={() => go({ kind: 'aircraft', section: 'tasks' })} />
        <StatTile kind={openSq ? 'over' : 'ok'} icon="squawk" n={openSq} label="Open squawks" danger={!!openSq} onClick={() => go({ kind: 'aircraft', section: 'squawks' })} />
      </div>

      <OverviewView aircraft={aircraft} go={go} />
    </div>
  );
}

Object.assign(window, { AircraftDashboard, CraftHero });
