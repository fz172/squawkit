/* ============================================================
   Hopply Web — root app + router (aircraft-scoped)
   route = { kind:'aircraft', section } | { kind:'global', name }
   ============================================================ */
const { AIRCRAFT: AC_ALL } = window.HOPPLY;

const SECTION_LABEL = { dashboard: 'Dashboard', tasks: 'Tasks', logs: 'Logs', squawks: 'Squawks' };
const GLOBAL_LABEL = { export: 'Export logs', settings: 'Settings' };

function readInitial() {
  const p = new URLSearchParams(location.search);
  const aircraftId = AC_ALL.find(a => a.id === p.get('aircraft'))?.id || AC_ALL[0].id;
  const section = p.get('section');
  const screen = p.get('screen');
  let route = { kind: 'aircraft', section: 'dashboard' };
  if (screen === 'export' || screen === 'settings') route = { kind: 'global', name: screen };
  else if (['dashboard', 'tasks', 'logs', 'squawks'].includes(section)) route = { kind: 'aircraft', section };
  const theme = p.get('theme');
  return {
    aircraftId,
    route,
    theme: theme === 'light' || theme === 'dark' ? theme : (localStorage.getItem('hopply-theme') || 'dark'),
    drawer: p.get('drawer') || null,
  };
}

function App() {
  const init = readInitial();
  const [aircraftId, setAircraftId] = useState(init.aircraftId);
  const [route, setRoute] = useState(init.route);
  const [theme, setTheme] = useState(init.theme);
  const [search, setSearch] = useState('');
  const [exportOpen, setExportOpen] = useState(init.drawer === 'export');
  const [taskEdit, setTaskEdit] = useState(null);
  const [squawkModal, setSquawkModal] = useState(init.drawer === 'squawk' ? init.aircraftId : null);
  const [logModal, setLogModal] = useState(null);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.add('theme-switching');
    root.setAttribute('data-theme', theme);
    localStorage.setItem('hopply-theme', theme);
    void root.offsetWidth; // force a reflow so the swap paints with transitions off
    const id = requestAnimationFrame(() => requestAnimationFrame(() => root.classList.remove('theme-switching')));
    return () => cancelAnimationFrame(id);
  }, [theme]);

  const aircraft = AC_ALL.find(a => a.id === aircraftId) || AC_ALL[0];
  const go = (r) => { setRoute(r); document.querySelector('.scroll')?.scrollTo(0, 0); };
  const pick = (id) => { setAircraftId(id); document.querySelector('.scroll')?.scrollTo(0, 0); };
  const toggleTheme = () => setTheme(t => t === 'dark' ? 'light' : 'dark');
  const openTaskEdit = (p) => setTaskEdit(p);
  const openSquawkModal = (id) => setSquawkModal(id || aircraftId);
  const openLogAdd = (id) => setLogModal(id || aircraftId);

  // ---- top bar config ----
  const isAircraft = route.kind === 'aircraft';
  const section = isAircraft ? route.section : route.name;
  let title, sub, searchOn = true, sectionLabel;

  if (isAircraft) {
    title = SECTION_LABEL[section];
    sub = `${aircraft.tail} · ${aircraft.name}`;
    sectionLabel = SECTION_LABEL[section];
  } else {
    title = GLOBAL_LABEL[section];
    sectionLabel = GLOBAL_LABEL[section];
    sub = section === 'export' ? 'Generate a maintenance report package' : 'Account, appearance & preferences';
    searchOn = false;
  }

  return (
    <div className="app">
      <Sidebar route={route} aircraft={aircraft} go={go} onPick={pick} />

      <div className="content">
        <TopBar title={title} sub={sub} search={searchOn ? search : false} onSearch={setSearch} theme={theme} toggleTheme={toggleTheme} />
        <MobileTop aircraft={aircraft} onPick={pick} theme={theme} toggleTheme={toggleTheme} sectionLabel={sectionLabel} />

        <div className="scroll">
          {isAircraft && section === 'dashboard' && <AircraftDashboard aircraft={aircraft} go={go} openTaskEdit={openTaskEdit} />}
          {isAircraft && section === 'tasks' && <div className="page"><TasksView aircraft={aircraft} openTaskEdit={openTaskEdit} /></div>}
          {isAircraft && section === 'logs' && <div className="page"><LogsView aircraft={aircraft} go={go} openLogAdd={openLogAdd} /></div>}
          {isAircraft && section === 'squawks' && <div className="page"><SquawksView aircraft={aircraft} openSquawkModal={openSquawkModal} /></div>}
          {!isAircraft && section === 'export' && <ExportScreen go={go} />}
          {!isAircraft && section === 'settings' && <Settings theme={theme} setTheme={setTheme} go={go} />}
        </div>
      </div>

      <BottomNav route={route} go={go} aircraftId={aircraftId} />

      {exportOpen && <ExportModal onClose={() => setExportOpen(false)} />}
      {taskEdit && <TaskEditModal payload={taskEdit} onClose={() => setTaskEdit(null)} />}
      {squawkModal && <SquawkModal aircraft={AC_ALL.find(a => a.id === squawkModal)} onClose={() => setSquawkModal(null)} />}
      {logModal && <LogModal aircraft={AC_ALL.find(a => a.id === logModal)} onClose={() => setLogModal(null)} />}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('app')).render(<App />);
