/* ============================================================
   Hopply Web — Settings
   ============================================================ */
const { USER: SET_USER, LOGS: SET_LOGS } = window.HOPPLY;

function SettingsCard({ title, action, children }) {
  return (
    <div className="card">
      <div className="card-h"><div className="card-t" style={{ flex: 1 }}>{title}</div>{action}</div>
      {children}
    </div>);
}

// derive the technicians who have signed off logs, with how many each signed
function deriveTechnicians() {
  const counts = {};
  Object.values(SET_LOGS).flat().forEach((l) => {
    if (l.tech) counts[l.tech] = (counts[l.tech] || 0) + 1;
  });
  // light role metadata for the demo dataset
  const ROLE = { 'R. Morales': 'A&P · IA', 'J. Hartley': 'A&P · IA', 'A. Okafor': 'A&P' };
  const CERT = { 'R. Morales': '3402199', 'J. Hartley': '2887051', 'A. Okafor': '4110782' };
  return Object.entries(counts)
    .map(([name, count]) => ({ name, count, role: ROLE[name] || 'A&P', cert: CERT[name] || '—' }))
    .sort((a, b) => b.count - a.count);
}

function initials(name) {
  return name.replace(/[^A-Za-z. ]/g, '').split(/[.\s]+/).filter(Boolean).map((p) => p[0]).slice(0, 2).join('').toUpperCase();
}

function Settings({ theme, setTheme, go }) {
  const techs = deriveTechnicians();

  return (
    <div className="page">
      <div className="set-grid">

        {/* account */}
        <div className="card">
          <div style={{ padding: 22, display: 'flex', alignItems: 'center', gap: 16 }}>
            <div className="sb-ava" style={{ width: 60, height: 60, display: 'grid', placeItems: 'center', color: 'var(--on-faint)', borderRadius: 18 }}>
              <Icon name="user" size={28} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: 'var(--font-head)', fontWeight: 700, fontSize: 19 }}>{SET_USER.name}</div>
              <div className="muted" style={{ fontSize: 13.5 }}>{SET_USER.cert} · Cert #{SET_USER.certNo}</div>
              {SET_USER.medicalExp && <div className="faint" style={{ fontSize: 12.5, marginTop: 1 }}>{SET_USER.medical} medical · expires {SET_USER.medicalExp}</div>}
            </div>
          </div>
        </div>

        {/* appearance */}
        <SettingsCard title="Appearance">
          <div className="set-row">
            <div className="mini-ico"><Icon name={theme === 'dark' ? 'moon' : 'sun'} size={18} /></div>
            <div className="set-main"><div className="set-t">Theme</div><div className="set-s">Choose how Hopply looks on this device</div></div>
            <div className="theme-switch">
              <button className={`theme-opt ${theme === 'light' ? 'active' : ''}`} onClick={() => setTheme('light')}><Icon name="sun" size={15} /> Light</button>
              <button className={`theme-opt ${theme === 'dark' ? 'active' : ''}`} onClick={() => setTheme('dark')}><Icon name="moon" size={15} /> Dark</button>
            </div>
          </div>
        </SettingsCard>

        {/* technician profiles */}
        <SettingsCard title="Technician profiles"
          action={<button className="btn btn-soft btn-sm"><Icon name="plus" size={15} stroke={2.2} /> Add technician</button>}>
          <div style={{ padding: '12px 20px 4px' }} className="muted">
            <span style={{ fontSize: 12.5 }}>People who can sign off maintenance entries on your aircraft.</span>
          </div>
          {techs.map((t) => (
            <div className="set-row" key={t.name}>
              <div className="tech-ava">{initials(t.name)}</div>
              <div className="set-main">
                <div className="set-t">{t.name}</div>
                <div className="set-s">{t.role} · Cert #{t.cert}</div>
              </div>
              <span className="muted mono" style={{ fontSize: 12, whiteSpace: 'nowrap' }}>{t.count} {t.count === 1 ? 'log' : 'logs'} signed</span>
              <button className="icon-btn" style={{ width: 34, height: 34 }} aria-label={`Edit ${t.name}`}><Icon name="edit" size={15} /></button>
            </div>
          ))}
        </SettingsCard>

        {/* data & privacy */}
        <SettingsCard title="Data & privacy">
          <div className="set-row">
            <div className="mini-ico"><Icon name="export" size={18} /></div>
            <div className="set-main"><div className="set-t">Export all logs</div><div className="set-s">Download a full ZIP of your maintenance records</div></div>
            <button className="btn btn-ghost btn-sm" onClick={() => go({ kind: 'global', name: 'export' })}>Export</button>
          </div>
          <div className="set-row">
            <div className="mini-ico"><Icon name="shield" size={18} /></div>
            <div className="set-main"><div className="set-t">Privacy policy</div><div className="set-s">How your records are stored and protected</div></div>
            <button className="icon-btn" style={{ width: 34, height: 34 }} aria-label="Open"><Icon name="arrowR" size={16} /></button>
          </div>
        </SettingsCard>

        {/* sign out */}
        <div className="card">
          <div className="set-row">
            <div className="mini-ico" style={{ color: 'var(--error)' }}><Icon name="logout" size={18} /></div>
            <div className="set-main"><div className="set-t" style={{ color: 'var(--error)' }}>Sign out</div><div className="set-s">You'll need to log in again</div></div>
            <button className="btn btn-danger-ghost btn-sm">Sign out</button>
          </div>
        </div>

        <div className="faint" style={{ textAlign: 'center', fontSize: 12, padding: '4px 0 8px' }}>Hopply · v2.4.0 · Made for pilots</div>
      </div>
    </div>);
}

Object.assign(window, { Settings });
