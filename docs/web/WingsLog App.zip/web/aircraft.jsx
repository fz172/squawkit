/* ============================================================
   Hopply Web — per-aircraft Tasks, Logs, Overview + drawers
   ============================================================ */
const { AIRCRAFT: AD_AC, TASKS: AD_TASKS, LOGS: AD_LOGS, SQUAWKS: AD_SQ, FILTER_TYPES: AD_FILTERS } = window.HOPPLY;

/* ---------- Log detail drawer ---------- */
function LogDrawer({ log, aircraft, go, onClose }) {
  const metric = log.type === 'ENGINE' ? { l: 'Engine Time', v: log.engineTime } :
    log.type === 'PROPELLER' ? { l: 'Propeller Time', v: log.propTime } :
    { l: 'Airframe Time', v: log.airframeTime };
  return (
    <Drawer title="Maintenance Entry" badge={<Badge type={log.type} />} onClose={onClose}
      footer={<><button className="btn btn-ghost" style={{ flex: 1 }} onClick={onClose}>Close</button>
        <button className="btn btn-primary" style={{ flex: 1 }}><Icon name="edit" size={16} /> Edit log</button></>}>
      <div className="detail-metric">
        <div className="dm-l">{metric.l}</div>
        <div className="dm-v mono">{metric.v}<span className="dm-u">hrs</span></div>
      </div>
      <div className="detail-row"><span className="dr-l">Component</span><span className="dr-v" style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}>{log.component}</span></div>
      <div className="detail-row"><span className="dr-l">Tach</span><span className="dr-v">{log.tach} hrs</span></div>
      <div className="detail-row"><span className="dr-l">Date</span><span className="dr-v">{log.date}</span></div>
      <div className="detail-desc">{log.desc}</div>
      <div style={{ fontFamily: 'var(--font-head)', fontWeight: 700, fontSize: 14, margin: '18px 0 12px' }}>Affected Maintenance Tasks</div>
      {log.tasks.length ? log.tasks.map((t, i) =>
        <div className="linked-task" key={i} onClick={() => { onClose(); go({ kind: 'aircraft', section: 'tasks' }); }}>
          <Icon name="tasks" size={17} style={{ color: 'var(--primary)' }} />
          <span style={{ flex: 1, fontWeight: 600, fontSize: 14 }}>{t}</span>
          <Icon name="chevR" size={15} style={{ color: 'var(--on-faint)' }} />
        </div>
      ) : <div className="muted" style={{ fontSize: 13.5, fontStyle: 'italic' }}>No tasks linked to this entry.</div>}
      <div className="detail-row" style={{ marginTop: 20, borderTop: '1px solid var(--outline-variant)', borderBottom: 'none' }}>
        <span className="dr-l">Signed off by</span><span className="dr-v" style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}>{log.tech}</span>
      </div>
    </Drawer>);
}

/* ---------- Task detail drawer ---------- */
function TaskDrawer({ task, aircraft, onClose, openTaskEdit }) {
  const over = task.kind === 'over';
  return (
    <Drawer title="Maintenance Task" badge={<StatusPill kind={task.kind === 'ok' ? 'ok' : task.kind} />} onClose={onClose}
      footer={<><button className="btn btn-ghost" style={{ flex: 1 }} onClick={onClose}>Close</button>
        <button className="btn btn-primary" style={{ flex: 1 }} onClick={() => { onClose(); openTaskEdit({ mode: 'edit', aircraftId: aircraft.id, task }); }}><Icon name="edit" size={16} /> Update task</button></>}>
      <div style={{ fontFamily: 'var(--font-head)', fontWeight: 700, fontSize: 24, letterSpacing: '-.02em', marginBottom: 18 }}>{task.name}</div>
      <div className="detail-metric">
        <div className="dm-l">{task.metric}</div>
        <div className={`dm-v mono ${over ? 'over' : ''}`}>{task.dueValue}{task.dueType === 'hrs' && <span className="dm-u">hrs</span>}</div>
        <div className="mono" style={{ fontWeight: 600, fontSize: 13, marginTop: 8, color: over ? 'var(--error)' : task.kind === 'warn' ? 'var(--warn)' : 'var(--on-variant)' }}>{task.remaining}</div>
      </div>
      <div className="detail-row"><span className="dr-l">Category</span><span className="dr-v"><Badge type={task.cat} /></span></div>
      <div className="detail-row"><span className="dr-l">Interval</span><span className="dr-v" style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}>{task.interval}</span></div>
      <div className="detail-row"><span className="dr-l">Due type</span><span className="dr-v" style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}>{task.dueType === 'hrs' ? 'Tach / engine hours' : 'Calendar date'}</span></div>
      <div style={{ fontFamily: 'var(--font-head)', fontWeight: 700, fontSize: 14, margin: '20px 0 8px' }}>Maintenance History</div>
      <EmptyState icon="history" title="No logs yet" sub="Add a maintenance entry and tag this task to see history here." />
    </Drawer>);
}

/* ---------- Logs table (shared) ---------- */
function LogsTable({ logs, onRow }) {
  return (
    <>
      <div className="table-wrap">
        <table className="logs">
          <thead>
            <tr>
              <th>Date</th><th>Type</th><th>Component</th>
              <th>Description</th><th style={{ textAlign: 'right' }}>Tach</th><th>Technician</th><th></th>
            </tr>
          </thead>
          <tbody>
            {logs.map((l) =>
              <tr key={l.id} onClick={() => onRow(l)}>
                <td className="c-date">{l.date}</td>
                <td><Badge type={l.type} /></td>
                <td className="c-comp">{l.component}</td>
                <td className="c-desc"><div className="clip">{l.desc}</div></td>
                <td className="c-hrs">{l.tach}</td>
                <td className="c-tech">{l.tech}</td>
                <td className="c-chev"><Icon name="chevR" size={15} /></td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* mobile cards */}
      <div className="log-cards">
        {logs.map((l) =>
          <div className="lcard" key={l.id} onClick={() => onRow(l)}>
            <div className="lcard-row">
              <Badge type={l.type} />
              <span className="mono muted" style={{ fontSize: 12, fontWeight: 600 }}>{l.tach} hrs</span>
            </div>
            <div style={{ fontSize: 14, lineHeight: 1.45 }}>{l.desc}</div>
            <div className="lcard-row" style={{ paddingTop: 10, borderTop: '1px solid var(--outline-variant)' }}>
              <span className="mono muted" style={{ fontSize: 12, fontWeight: 600 }}>{l.date}</span>
              <span className="muted" style={{ fontSize: 12 }}>{l.tech}</span>
            </div>
          </div>
        )}
      </div>
    </>);
}

/* ---------- Logs view ---------- */
function LogsView({ aircraft, go, openLogAdd }) {
  const logs = AD_LOGS[aircraft.id] || [];
  const [q, setQ] = useState('');
  const [filters, setFilters] = useState([]);
  const [openLog, setOpenLog] = useState(null);

  const toggle = (t) => setFilters((f) => f.includes(t) ? f.filter((x) => x !== t) : [...f, t]);
  const visible = logs.filter((l) => {
    if (filters.length && !filters.includes(l.type[0] + l.type.slice(1).toLowerCase())) return false;
    if (q && !(l.desc + l.component + l.tech).toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  });

  return (
    <div>
      <div className="toolbar">
        <div className="tb-search" style={{ height: 38 }}>
          <Icon name="search" size={16} />
          <input placeholder="Search entries…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        {AD_FILTERS.map((f) =>
          <button key={f} className={`chip ${filters.includes(f) ? 'active' : ''}`} onClick={() => toggle(f)}>
            {filters.includes(f) && <Icon name="check" size={13} stroke={2.4} />}{f}
          </button>
        )}
        <div style={{ flex: 1 }} />
        <span className="sec-label hide-mobile">{visible.length} {visible.length === 1 ? 'entry' : 'entries'}</span>
        <button className="btn btn-primary" onClick={() => openLogAdd && openLogAdd(aircraft.id)}>
          <Icon name="plus" size={16} stroke={2.2} /> New entry
        </button>
      </div>
      {visible.length
        ? <LogsTable logs={visible} onRow={setOpenLog} />
        : <div className="card"><EmptyState icon="logs" title="No matching entries" sub="Try clearing filters or your search." /></div>}
      {openLog && <LogDrawer log={openLog} aircraft={aircraft} go={go} onClose={() => setOpenLog(null)} />}
    </div>);
}

/* ---------- Tasks ---------- */
function TaskCard({ t, onClick }) {
  return (
    <div className={`tcard ${t.kind === 'over' ? 'over' : ''}`} onClick={() => onClick(t)}>
      <div className="tcard-top">
        <div className="tcard-name">{t.name}</div>
        {t.kind === 'over' ? <StatusPill kind="over" children="Overdue" /> : <Badge type={t.cat} />}
      </div>
      <div className="flex ac g8">
        <Icon name={t.dueType === 'hrs' ? 'gauge' : 'cal'} size={15} style={{ color: 'var(--on-faint)' }} />
        <span className="muted" style={{ fontSize: 12.5 }}>{t.interval}</span>
      </div>
      <div className="tcard-foot">
        <div>
          <div className="tcard-due-l">{t.metric}</div>
          <div className={`tcard-due-v mono ${t.kind === 'over' ? 'over' : t.kind === 'warn' ? 'warn' : ''}`}>
            {t.dueValue}{t.dueType === 'hrs' ? <span style={{ fontSize: 12, color: 'var(--on-faint)', fontWeight: 500 }}> hrs</span> : ''}
          </div>
        </div>
        <div className="mono" style={{ fontSize: 12.5, fontWeight: 600, textAlign: 'right', color: t.kind === 'over' ? 'var(--error)' : t.kind === 'warn' ? 'var(--warn)' : 'var(--on-variant)' }}>{t.remaining}</div>
      </div>
    </div>);
}

function TasksView({ aircraft, openTaskEdit }) {
  const data = AD_TASKS[aircraft.id] || { due: [], history: [] };
  const [seg, setSeg] = useState('due');
  const [openTask, setOpenTask] = useState(null);
  const list = seg === 'due' ? data.due : data.history;

  return (
    <div>
      <div className="flex ac jb g12" style={{ marginBottom: 18, flexWrap: 'wrap' }}>
        <Segmented value={seg} onChange={setSeg}
          options={[{ value: 'due', label: 'Due', count: data.due.length }, { value: 'history', label: 'History', count: data.history.length }]} />
        <button className="btn btn-primary" onClick={() => openTaskEdit({ mode: 'add', aircraftId: aircraft.id })}>
          <Icon name="plus" size={16} stroke={2.2} /> New task
        </button>
      </div>
      {list.length
        ? <div className="task-grid">{list.map((t) => <TaskCard key={t.id} t={t} onClick={setOpenTask} />)}</div>
        : <div className="card"><EmptyState icon="check" title={seg === 'due' ? 'Nothing due' : 'No history yet'} sub={seg === 'due' ? 'All scheduled maintenance is up to date.' : 'Completed tasks will appear here.'} /></div>}
      {openTask && <TaskDrawer task={openTask} aircraft={aircraft} onClose={() => setOpenTask(null)} openTaskEdit={openTaskEdit} />}
    </div>);
}

/* ---------- Overview (used inside the per-aircraft dashboard) ---------- */
function OverviewView({ aircraft, go }) {
  const logs = AD_LOGS[aircraft.id] || [];
  const due = AD_TASKS[aircraft.id]?.due || [];
  const next = due.find((t) => t.kind === 'over') || due.find((t) => t.kind === 'warn') || due[0];
  const openSq = (AD_SQ[aircraft.id] || []).filter((s) => s.status === 'open');

  return (
    <div className="two-col">
      <div className="col" style={{ gap: 22 }}>
        <div className="card">
          <div className="card-h"><div className="card-t" style={{ flex: 1 }}>Recent Activity</div>
            <a className="link-btn" onClick={() => go({ kind: 'aircraft', section: 'logs' })}>All logs <Icon name="arrowR" size={13} /></a></div>
          <div className="mini-list">
            {logs.slice(0, 4).map((l) =>
              <div className="mini-row" key={l.id} onClick={() => go({ kind: 'aircraft', section: 'logs' })}>
                <div className="mini-ico"><Badge type={l.type} /></div>
                <div className="mini-main"><div className="mini-t">{l.component}</div><div className="mini-s">{l.desc.slice(0, 60)}…</div></div>
                <div className="mini-r">{l.date}<br /><span style={{ color: 'var(--on-faint)' }}>{l.tach} hrs</span></div>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="col" style={{ gap: 22 }}>
        {next &&
          <div className="card" style={{ padding: 22 }}>
            <div className="sec-label" style={{ marginBottom: 12 }}>Next due</div>
            <div className="flex ac jb g12" style={{ marginBottom: 14 }}>
              <div style={{ fontFamily: 'var(--font-head)', fontWeight: 700, fontSize: 19, letterSpacing: '-.01em' }}>{next.name}</div>
              <StatusPill kind={next.kind === 'ok' ? 'ok' : next.kind} children={next.kind === 'over' ? 'Overdue' : next.kind === 'warn' ? 'Due soon' : 'On track'} />
            </div>
            <div className={`mono ${next.kind === 'over' ? 'over' : ''}`} style={{ fontWeight: 700, fontSize: 34, letterSpacing: '-.02em', color: next.kind === 'over' ? 'var(--error)' : 'var(--primary)' }}>
              {next.dueValue}<span style={{ fontFamily: 'var(--font-body)', fontSize: 15, color: 'var(--on-faint)', fontWeight: 500 }}> {next.dueType === 'hrs' ? 'hrs' : ''}</span>
            </div>
            <div className="muted" style={{ fontSize: 13, marginTop: 6 }}>{next.metric} · {next.remaining}</div>
            <button className="btn btn-soft" style={{ width: '100%', marginTop: 18 }} onClick={() => go({ kind: 'aircraft', section: 'tasks' })}>View all tasks</button>
          </div>
        }

        <div className="card">
          <div className="card-h">
            <Icon name="squawk" size={17} style={{ color: openSq.length ? 'var(--error)' : 'var(--on-faint)' }} />
            <div className="card-t" style={{ flex: 1 }}>Open Squawks</div>
            <a className="link-btn" onClick={() => go({ kind: 'aircraft', section: 'squawks' })}>All <Icon name="arrowR" size={13} /></a>
          </div>
          {openSq.length ? (
            <div className="mini-list">
              {openSq.slice(0, 3).map((s) => {
                const sev = window.SEV[s.severity];
                return (
                  <div className="mini-row" key={s.id} onClick={() => go({ kind: 'aircraft', section: 'squawks' })}>
                    <div className="mini-main">
                      <div className="mini-t" style={{ display: '-webkit-box', WebkitLineClamp: 1, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{s.title}</div>
                      <div className="mini-s">{s.system} · {s.date}</div>
                    </div>
                    <span className={`pill ${sev.pill}`} style={{ flexShrink: 0 }}><span className="pdot" />{sev.label}</span>
                  </div>
                );
              })}
            </div>
          ) : <div style={{ padding: '20px' }}><EmptyState icon="checkCircle" title="No open squawks" /></div>}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { OverviewView, TasksView, LogsView, LogsTable, LogDrawer, TaskDrawer, TaskCard, LogModal });

/* ---------- Add maintenance log modal ---------- */
function LogModal({ aircraft, onClose }) {
  const [type, setType] = useState('Engine');
  const footer = (
    <>
      <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
      <div style={{ flex: 1 }} />
      <button className="btn btn-primary" onClick={onClose}><Icon name="check" size={16} stroke={2.4} /> Save entry</button>
    </>
  );
  return (
    <Modal title="New maintenance entry" onClose={onClose} footer={footer}>
      <div className="muted" style={{ fontSize: 12.5, marginBottom: 18, marginTop: -4 }}>
        For <span className="mono" style={{ color: 'var(--tail)', fontWeight: 700 }}>{aircraft.tail}</span> · {aircraft.name}
      </div>
      <div className="field">
        <label className="field-l">Log type</label>
        <div className="flex g8" style={{ flexWrap: 'wrap' }}>
          {AD_FILTERS.map((c) =>
            <button key={c} className={`chip ${type === c ? 'active' : ''}`} style={{ height: 38 }} onClick={() => setType(c)}>
              {type === c && <Icon name="check" size={13} stroke={2.4} />}{c}
            </button>
          )}
        </div>
      </div>
      <div className="field"><label className="field-l">Component</label><input className="input" placeholder="e.g. Lycoming IO-360" /></div>
      <div className="field"><label className="field-l">Work performed</label><textarea className="input" placeholder="What was done, torque values, references…" /></div>
      <div className="row-2" style={{ gridTemplateColumns: '1fr 1fr', marginBottom: 18 }}>
        <div><label className="field-l">Tach / hours</label><input className="input mono" placeholder={aircraft.tach} /></div>
        <div><label className="field-l">Date</label><input className="input" type="date" /></div>
      </div>
      <div className="field" style={{ marginBottom: 0 }}>
        <label className="field-l">Technician</label>
        <input className="input" placeholder="Who signed it off" />
      </div>
    </Modal>
  );
}

Object.assign(window, { LogModal });
