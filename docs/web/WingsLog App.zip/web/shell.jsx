/* ============================================================
   Hopply Web — app shell (switcher / sidebar / topbar / bottom nav)
   Aircraft-scoped: per-aircraft sections + global section.
   ============================================================ */
const { AIRCRAFT, TASKS: SHELL_TASKS, SQUAWKS: SHELL_SQ, USER } = window.HOPPLY;

const PER_AIRCRAFT_NAV = [
  { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
  { id: 'tasks',     label: 'Tasks',     icon: 'tasks' },
  { id: 'logs',      label: 'Logs',      icon: 'logs' },
  { id: 'squawks',   label: 'Squawks',   icon: 'squawk' },
];
const GLOBAL_NAV = [
  { id: 'settings', label: 'Settings', icon: 'settings' },
];

const overdueOf = (id) => ((SHELL_TASKS[id]?.due) || []).filter(t => t.kind === 'over').length;
const openSquawksOf = (id) => (SHELL_SQ[id] || []).filter(s => s.status === 'open').length;

function badgeFor(navId, aircraftId) {
  if (navId === 'tasks') { const n = overdueOf(aircraftId); return n ? { n, cls: 'over' } : null; }
  if (navId === 'squawks') { const n = openSquawksOf(aircraftId); return n ? { n, cls: 'sq' } : null; }
  return null;
}

/* ---------- Aircraft switcher ---------- */
function Switcher({ aircraft, onPick }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    const h = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    window.addEventListener('mousedown', h);
    return () => window.removeEventListener('mousedown', h);
  }, []);
  return (
    <div className="sb-switcher" ref={ref}>
      <button className={`switcher-btn ${open ? 'open' : ''}`} onClick={() => setOpen(o => !o)} title="Switch aircraft">
        <Dot kind={aircraft.status} />
        <div className="switcher-meta">
          <div className="switcher-tail">{aircraft.tail}</div>
          <div className="switcher-name">{aircraft.name}</div>
        </div>
        <Icon name="chevR" size={16} className="switcher-chev" style={{ transform: 'rotate(90deg)' }} />
      </button>
      {open && (
        <div className="switcher-pop">
          <div className="sb-section-label" style={{ padding: '6px 11px 4px' }}>Switch aircraft</div>
          {AIRCRAFT.map(a => {
            const od = overdueOf(a.id), sq = openSquawksOf(a.id);
            return (
              <div key={a.id} className={`switcher-opt ${a.id === aircraft.id ? 'active' : ''}`}
                onClick={() => { onPick(a.id); setOpen(false); }}>
                <Dot kind={a.status} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="switcher-tail">{a.tail}</div>
                  <div className="switcher-name">{a.name}</div>
                </div>
                {(od + sq) > 0 && <span className="nav-badge" style={{ marginLeft: 0 }}>{od + sq}</span>}
                {a.id === aircraft.id && <Icon name="check" size={15} stroke={2.4} style={{ color: 'var(--primary)' }} />}
              </div>
            );
          })}
          <div className="switcher-pop-foot">
            <div className="switcher-opt" onClick={() => { onPick(aircraft.id); setOpen(false); }} style={{ color: 'var(--on-variant)' }}>
              <div className="mini-ico" style={{ width: 28, height: 28, borderRadius: 8 }}><Icon name="plus" size={15} /></div>
              <span style={{ fontSize: 13, fontWeight: 600 }}>Add aircraft</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Sidebar({ route, aircraft, go, onPick }) {
  const isAircraft = route.kind === 'aircraft';
  return (
    <nav className="sidebar">
      <div className="sb-brand">
        <div className="sb-logo"><Icon name="plane" size={20} fill /></div>
        <div className="sb-word sb-label">Hopply</div>
      </div>

      <Switcher aircraft={aircraft} onPick={onPick} />

      <div className="sb-section-label sb-label">This aircraft</div>
      <div className="sb-nav">
        {PER_AIRCRAFT_NAV.map(n => {
          const b = badgeFor(n.id, aircraft.id);
          return (
            <a key={n.id} className={`nav-item ${isAircraft && route.section === n.id ? 'active' : ''}`}
              onClick={() => go({ kind: 'aircraft', section: n.id })} title={n.label}>
              <Icon name={n.icon} size={20} />
              <span className="nav-label">{n.label}</span>
              {b && <span className={`nav-badge ${b.cls === 'sq' ? 'sq' : ''}`}>{b.n}</span>}
            </a>
          );
        })}
      </div>

      <div className="sb-divider" />
      <div className="sb-section-label sb-label">Workspace</div>
      <div className="sb-nav">
        {GLOBAL_NAV.map(n => (
          <a key={n.id} className={`nav-item ${route.kind === 'global' && route.name === n.id ? 'active' : ''}`}
            onClick={() => go({ kind: 'global', name: n.id })} title={n.label}>
            <Icon name={n.icon} size={20} />
            <span className="nav-label">{n.label}</span>
          </a>
        ))}
      </div>

      <div style={{ flex: 1 }} />
      <div className="sb-foot">
        <a className="sb-user" onClick={() => go({ kind: 'global', name: 'settings' })}>
          <div className="sb-ava" style={{ display: 'grid', placeItems: 'center', color: 'var(--on-faint)' }}>
            <Icon name="user" size={18} />
          </div>
          <div className="craft-meta sb-label">
            <div className="sb-user-name">{USER.name}</div>
            <div className="sb-user-mail">{USER.email}</div>
          </div>
        </a>
      </div>
    </nav>
  );
}

function TopBar({ title, sub, actions, search, onSearch, theme, toggleTheme }) {
  return (
    <header className="topbar">
      <div style={{ minWidth: 0 }}>
        <div className="tb-title">{title}</div>
        {sub && <div className="tb-sub">{sub}</div>}
      </div>
      <div className="tb-spacer" />
      <button className="icon-btn" onClick={toggleTheme} aria-label="Toggle theme" title="Toggle theme">
        <Icon name={theme === 'dark' ? 'sun' : 'moon'} size={19} />
      </button>
      <button className="icon-btn" aria-label="Notifications">
        <Icon name="bell" size={19} />
      </button>
    </header>
  );
}

/* ---------- Mobile top: aircraft switcher inline ---------- */
function MobileTop({ aircraft, onPick, theme, toggleTheme, sectionLabel }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    const h = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    window.addEventListener('mousedown', h);
    return () => window.removeEventListener('mousedown', h);
  }, []);
  return (
    <header className="mtop">
      <div className="msw" ref={ref}>
        <button className={`msw-btn ${open ? 'open' : ''}`} onClick={() => setOpen(o => !o)}>
          <Dot kind={aircraft.status} />
          <div style={{ minWidth: 0, textAlign: 'left' }}>
            <div className="switcher-tail">{aircraft.tail}</div>
            <div className="switcher-name" style={{ fontSize: 11 }}>{sectionLabel}</div>
          </div>
          <Icon name="chevR" size={15} style={{ transform: 'rotate(90deg)', color: 'var(--on-faint)' }} />
        </button>
        {open && (
          <div className="switcher-pop" style={{ left: 0, minWidth: 240 }}>
            <div className="sb-section-label" style={{ padding: '6px 11px 4px' }}>Switch aircraft</div>
            {AIRCRAFT.map(a => (
              <div key={a.id} className={`switcher-opt ${a.id === aircraft.id ? 'active' : ''}`}
                onClick={() => { onPick(a.id); setOpen(false); }}>
                <Dot kind={a.status} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="switcher-tail">{a.tail}</div>
                  <div className="switcher-name">{a.name}</div>
                </div>
                {a.id === aircraft.id && <Icon name="check" size={15} stroke={2.4} style={{ color: 'var(--primary)' }} />}
              </div>
            ))}
          </div>
        )}
      </div>
      <div style={{ flex: 1 }} />
      <button className="icon-btn" style={{ width: 38, height: 38 }} onClick={toggleTheme} aria-label="Theme">
        <Icon name={theme === 'dark' ? 'sun' : 'moon'} size={18} />
      </button>
    </header>
  );
}

function BottomNav({ route, go, aircraftId }) {
  const items = [
    ...PER_AIRCRAFT_NAV,
    { id: 'settings', label: 'Settings', icon: 'settings', global: true },
  ];
  const activeId = route.kind === 'aircraft' ? route.section : route.name;
  return (
    <nav className="bottomnav">
      {items.map(n => {
        const b = !n.global ? badgeFor(n.id, aircraftId) : null;
        return (
          <a key={n.id} className={`bn-item ${activeId === n.id ? 'active' : ''}`}
            onClick={() => go(n.global ? { kind: 'global', name: n.id } : { kind: 'aircraft', section: n.id })}>
            <span className="bn-ico-wrap">
              <Icon name={n.icon} size={21} />
              {b && <span className="bn-dot" />}
            </span>
            {n.label}
          </a>
        );
      })}
    </nav>
  );
}

Object.assign(window, { Sidebar, TopBar, MobileTop, BottomNav, PER_AIRCRAFT_NAV, GLOBAL_NAV });
