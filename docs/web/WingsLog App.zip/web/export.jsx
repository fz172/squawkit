/* ============================================================
   Hopply Web — Export flow
   ============================================================ */
const { AIRCRAFT: EX_AC, USER: EX_USER } = window.HOPPLY;

const FORMATS = [
  { id: 'pdf', name: 'PDF', sub: 'Print-ready', icon: 'pdf' },
  { id: 'csv', name: 'CSV', sub: 'Plain text', icon: 'csv' },
  { id: 'xlsx', name: 'XLSX', sub: 'Spreadsheet', icon: 'xlsx' },
];
const RANGES = [{ id: 'all', label: 'All time' }, { id: '12m', label: 'Last 12 months' }, { id: 'custom', label: 'Custom' }];

function ExportConfig({ onDone }) {
  const [fmts, setFmts] = useState(['pdf', 'csv', 'xlsx']);
  const [craft, setCraft] = useState(EX_AC.map(a => a.id));
  const [range, setRange] = useState('all');
  const [done, setDone] = useState(false);

  const toggleF = (id) => setFmts(f => f.includes(id) ? f.filter(x => x !== id) : [...f, id]);
  const toggleC = (id) => setCraft(c => c.includes(id) ? c.filter(x => x !== id) : [...c, id]);
  const size = (craft.length * 1.7 * fmts.length / 1.4).toFixed(1);
  const canExport = fmts.length && craft.length;

  return (
    <div className="export-grid">
      <div className="col" style={{ gap: 26 }}>
        {/* formats */}
        <div>
          <div className="sec-label" style={{ marginBottom: 12 }}>Report formats</div>
          <div className="fmt-grid">
            {FORMATS.map(f => {
              const on = fmts.includes(f.id);
              return (
                <div key={f.id} className={`fmt ${on ? 'on' : ''}`} onClick={() => toggleF(f.id)}>
                  <div className="fmt-chk"><Check on={on} /></div>
                  <div className="fmt-ico"><Icon name={f.icon} size={20} /></div>
                  <div className="fmt-t">{f.name}</div>
                  <div className="fmt-s">{f.sub}</div>
                </div>
              );
            })}
          </div>
          <div className="flex ac g8 muted" style={{ marginTop: 12, fontSize: 12.5 }}>
            <Icon name="zip" size={15} /> Bundled in a ZIP with your attached files.
          </div>
        </div>

        {/* aircraft */}
        <div>
          <div className="flex ac jb" style={{ marginBottom: 12 }}>
            <div className="sec-label">Aircraft</div>
            <a className="link-btn" onClick={() => setCraft(craft.length === EX_AC.length ? [] : EX_AC.map(a => a.id))}>
              {craft.length === EX_AC.length ? 'Clear all' : 'Select all'}
            </a>
          </div>
          {EX_AC.map(a => {
            const on = craft.includes(a.id);
            return (
              <div key={a.id} className={`export-craft ${on ? 'on' : ''}`} onClick={() => toggleC(a.id)}>
                <Check on={on} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="mono" style={{ fontWeight: 700, fontSize: 14, color: 'var(--tail)' }}>{a.tail}</div>
                  <div className="muted" style={{ fontSize: 12.5 }}>{a.name}</div>
                </div>
                <span className="muted mono" style={{ fontSize: 12 }}>{(window.HOPPLY.LOGS[a.id] || []).length} logs</span>
              </div>
            );
          })}
        </div>

        {/* range */}
        <div>
          <div className="sec-label" style={{ marginBottom: 12 }}>Date range</div>
          <div className="flex g8" style={{ flexWrap: 'wrap' }}>
            {RANGES.map(r => (
              <button key={r.id} className={`chip ${range === r.id ? 'active' : ''}`} style={{ height: 40 }} onClick={() => setRange(r.id)}>{r.label}</button>
            ))}
          </div>
          {range === 'custom' && (
            <div className="row-2" style={{ marginTop: 14, gridTemplateColumns: '1fr auto 1fr' }}>
              <input className="input" type="date" />
              <span className="or-chip">TO</span>
              <input className="input" type="date" />
            </div>
          )}
        </div>
      </div>

      {/* summary */}
      <div className="summary">
        <div style={{ padding: '18px 20px', borderBottom: '1px solid var(--outline-variant)' }}>
          <div style={{ fontFamily: 'var(--font-head)', fontWeight: 700, fontSize: 15 }}>Export summary</div>
        </div>
        <div className="summary-row"><span className="sr-l">Formats</span><span className="sr-v">{fmts.length ? fmts.map(f => f.toUpperCase()).join(' · ') : '—'}</span></div>
        <div className="summary-row"><span className="sr-l">Aircraft</span><span className="sr-v">{craft.length} of {EX_AC.length}</span></div>
        <div className="summary-row"><span className="sr-l">Range</span><span className="sr-v" style={{ fontFamily: 'var(--font-body)' }}>{RANGES.find(r => r.id === range).label}</span></div>
        <div className="summary-row"><span className="sr-l">Est. size</span><span className="sr-v">~{size} MB</span></div>
        <div style={{ padding: '16px 20px' }}>
          <div className="muted" style={{ fontSize: 12.5, lineHeight: 1.5, marginBottom: 14 }}>
            <Icon name="export" size={13} style={{ verticalAlign: '-2px' }} /> Sent to <b style={{ color: 'var(--on-surface)' }}>{EX_USER.email}</b>
          </div>
          <button className="btn btn-primary btn-lg" style={{ width: '100%' }} disabled={!canExport}
            onClick={() => { setDone(true); setTimeout(() => { setDone(false); onDone && onDone(); }, 1400); }}>
            {done ? <><Icon name="check" size={18} stroke={2.4} /> Export started</> : <><Icon name="zip" size={18} /> Export ZIP</>}
          </button>
        </div>
      </div>
    </div>
  );
}

function ExportScreen({ go }) {
  return <div className="page"><ExportConfig onDone={() => go && go({ kind: 'aircraft', section: 'dashboard' })} /></div>;
}

function ExportModal({ onClose }) {
  return (
    <Modal title="Export logs" onClose={onClose}>
      <ExportConfig onDone={onClose} />
    </Modal>
  );
}

Object.assign(window, { ExportScreen, ExportModal });
