/* ============================================================
   Hopply Web — Squawks (pilot-reported defects), per aircraft
   ============================================================ */
const { SQUAWKS: SQ_DATA, SQUAWK_SYSTEMS: SQ_SYS } = window.HOPPLY;

const SEV = {
  grounding: { label: 'Grounding', pill: 'grounding' },
  monitor:   { label: 'Monitor',   pill: 'monitor' },
  minor:     { label: 'Minor',     pill: 'minor' },
};
const STATUS = {
  open:     { label: 'Open',     pill: 'over', icon: 'squawk' },
  deferred: { label: 'Deferred', pill: 'deferred', icon: 'pause' },
  resolved: { label: 'Resolved', pill: 'resolved', icon: 'checkCircle' },
};

function SquawkCard({ s, onClick }) {
  const sev = SEV[s.severity];
  return (
    <div className={`scard ${s.severity} ${s.status === 'resolved' ? 'resolved' : ''}`} onClick={() => onClick(s)}>
      <div className="scard-top">
        <div className="scard-title">{s.title}</div>
        <span className={`pill ${sev.pill}`}><span className="pdot" />{sev.label}</span>
      </div>
      <div className="scard-desc">{s.desc}</div>
      <div className="scard-foot">
        <span className="flex ac g8">
          <Badge type={s.system} />
          <span className="mono" style={{ fontSize: 11.5 }}>{s.date}</span>
        </span>
        <span className="flex ac" style={{ gap: 5, fontWeight: 600, color: s.status === 'open' ? 'var(--error)' : s.status === 'resolved' ? 'var(--ok)' : 'var(--on-variant)' }}>
          <Icon name={STATUS[s.status].icon} size={13} />{STATUS[s.status].label}
        </span>
      </div>
    </div>
  );
}

function SquawkDrawer({ squawk: s, aircraft, onClose, onResolve }) {
  const sev = SEV[s.severity];
  return (
    <Drawer title="Squawk" badge={<span className={`pill ${sev.pill}`}><span className="pdot" />{sev.label}</span>} onClose={onClose}
      footer={(s.status === 'resolved' || s.status === 'deferred')
        ? <><button className="btn btn-ghost" style={{ flex: 1 }} onClick={onClose}>Close</button>
            <button className="btn btn-ghost" style={{ flex: 1 }} onClick={onClose}>Reopen</button>
            <button className="btn btn-primary" style={{ flex: 1 }} onClick={() => { onResolve && onResolve(s); onClose(); }}>
              <Icon name="checkCircle" size={16} /> Update</button></>
        : <><button className="btn btn-ghost" style={{ flex: 1 }} onClick={onClose}>Close</button>
            <button className="btn btn-ghost" style={{ flex: 1 }} onClick={onClose}>Dismiss</button>
            <button className="btn btn-primary" style={{ flex: 1 }} onClick={() => { onResolve && onResolve(s); onClose(); }}>
              <Icon name="checkCircle" size={16} /> Update</button></>}>
      <div style={{ fontFamily: 'var(--font-head)', fontWeight: 700, fontSize: 21, letterSpacing: '-.01em', lineHeight: 1.25, marginBottom: 16 }}>{s.title}</div>
      <div className="flex ac g8" style={{ marginBottom: 18 }}>
        <span className="flex ac" style={{ gap: 5, fontSize: 12.5, fontWeight: 700, padding: '4px 10px', borderRadius: 99,
          background: s.status === 'open' ? 'var(--error-container)' : s.status === 'resolved' ? 'var(--ok-container)' : 'var(--surface-sunken)',
          color: s.status === 'open' ? 'var(--error)' : s.status === 'resolved' ? 'var(--ok)' : 'var(--on-variant)' }}>
          <Icon name={STATUS[s.status].icon} size={13} />{STATUS[s.status].label}
        </span>
        <Badge type={s.system} />
      </div>
      <div className="detail-desc" style={{ borderTop: '1px solid var(--outline-variant)', paddingTop: 16 }}>{s.desc}</div>
      <div className="detail-row"><span className="dr-l">Reported by</span><span className="dr-v" style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}>{s.reportedBy}</span></div>
      <div className="detail-row"><span className="dr-l">Date reported</span><span className="dr-v">{s.date}</span></div>
      <div className="detail-row"><span className="dr-l">Flight</span><span className="dr-v" style={{ fontFamily: 'var(--font-body)', fontWeight: 600 }}>{s.flight}</span></div>
      {s.status === 'resolved' && (
        <>
          <div className="detail-row"><span className="dr-l">Resolved</span><span className="dr-v" style={{ color: 'var(--ok)' }}>{s.resolvedDate}</span></div>
          <div style={{ fontFamily: 'var(--font-head)', fontWeight: 700, fontSize: 14, margin: '20px 0 10px' }}>Resolved by log</div>
          <div className="linked-task">
            <Icon name="logs" size={17} style={{ color: 'var(--primary)' }} />
            <span style={{ flex: 1, fontWeight: 600, fontSize: 14 }}>{s.resolvedLog}</span>
            <Icon name="chevR" size={15} style={{ color: 'var(--on-faint)' }} />
          </div>
        </>
      )}
      {s.status !== 'resolved' && (
        <div style={{ marginTop: 18 }}>
          <button className="btn btn-ghost" style={{ width: '100%', borderStyle: 'dashed' }}>
            <Icon name="link" size={16} /> Link to a maintenance log
          </button>
        </div>
      )}
    </Drawer>
  );
}

function SquawkModal({ aircraft, onClose }) {
  const [sev, setSev] = useState('monitor');
  const [sys, setSys] = useState('Engine');
  const footer = (
    <>
      <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
      <div style={{ flex: 1 }} />
      <button className="btn btn-primary" onClick={onClose}><Icon name="squawk" size={16} /> Report squawk</button>
    </>
  );
  return (
    <Modal title="Report a squawk" onClose={onClose} footer={footer}>
      <div className="muted" style={{ fontSize: 12.5, marginBottom: 18, marginTop: -4 }}>
        For <span className="mono" style={{ color: 'var(--tail)', fontWeight: 700 }}>{aircraft.tail}</span> · {aircraft.name}
      </div>
      <div className="field">
        <label className="field-l">What did you notice?</label>
        <input className="input" placeholder="e.g. Right brake feels soft on taxi" />
      </div>
      <div className="field">
        <label className="field-l">Details</label>
        <textarea className="input" placeholder="When it happens, what you observed, any troubleshooting…" />
      </div>
      <div className="field">
        <label className="field-l">Severity</label>
        <div className="flex g8" style={{ flexWrap: 'wrap' }}>
          {Object.entries(SEV).map(([k, v]) => (
            <button key={k} className={`chip ${sev === k ? 'active' : ''}`} style={{ height: 38 }} onClick={() => setSev(k)}>
              {sev === k && <Icon name="check" size={13} stroke={2.4} />}{v.label}
            </button>
          ))}
        </div>
        <div className="field-hint">"Grounding" marks the aircraft no-go until resolved.</div>
      </div>
      <div className="field" style={{ marginBottom: 0 }}>
        <label className="field-l">System</label>
        <div className="flex g8" style={{ flexWrap: 'wrap' }}>
          {SQ_SYS.map(c => (
            <button key={c} className={`chip ${sys === c ? 'active' : ''}`} style={{ height: 38 }} onClick={() => setSys(c)}>
              {sys === c && <Icon name="check" size={13} stroke={2.4} />}{c}
            </button>
          ))}
        </div>
      </div>
    </Modal>
  );
}

function SquawksView({ aircraft, openSquawkModal }) {
  const all = SQ_DATA[aircraft.id] || [];
  const [scope, setScope] = useState('open');
  const [open, setOpen] = useState(null);

  const counts = {
    open: all.filter(s => s.status === 'open').length,
    closed: all.filter(s => s.status === 'deferred' || s.status === 'resolved').length,
    all: all.length,
  };
  const visible = scope === 'all' ? all
    : scope === 'closed' ? all.filter(s => s.status === 'deferred' || s.status === 'resolved')
    : all.filter(s => s.status === scope);
  const grounded = all.some(s => s.status === 'open' && s.severity === 'grounding');

  return (
    <div>
      {grounded && (
        <div className="grounded-banner">
          <Icon name="squawk" size={20} />
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 14 }}>Open grounding squawk</div>
            <div style={{ fontSize: 12.5, opacity: .9 }}>This aircraft has a no-go defect. Resolve before next flight.</div>
          </div>
        </div>
      )}

      <div className="flex ac jb g12" style={{ marginBottom: 18, flexWrap: 'wrap' }}>
        <Segmented value={scope} onChange={setScope}
          options={[
            { value: 'open', label: 'Open', count: counts.open },
            { value: 'closed', label: 'Closed', count: counts.closed },
          ]} />
        <button className="btn btn-primary" onClick={() => openSquawkModal(aircraft.id)}>
          <Icon name="plus" size={16} stroke={2.2} /> Report squawk
        </button>
      </div>

      {visible.length
        ? <div className="sq-grid">{visible.map(s => <SquawkCard key={s.id} s={s} onClick={setOpen} />)}</div>
        : <div className="card"><EmptyState icon="checkCircle"
            title={scope === 'open' ? 'No open squawks' : scope === 'closed' ? 'No closed squawks' : 'Nothing here'}
            sub={scope === 'open' ? 'This aircraft has no reported defects. Clear skies.' : 'Reported defects in this state will appear here.'} /></div>}

      {open && <SquawkDrawer squawk={open} aircraft={aircraft} onClose={() => setOpen(null)} />}
    </div>
  );
}

Object.assign(window, { SquawksView, SquawkCard, SquawkDrawer, SquawkModal, SEV: SEV, SQ_STATUS: STATUS });
