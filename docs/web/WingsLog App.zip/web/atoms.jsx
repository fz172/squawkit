/* ============================================================
   Hopply Web — shared atoms
   ============================================================ */
const { useState, useEffect, useRef } = React;
const { I } = window.HOPPLY;

// Inline icon. Stroked, 24px grid, currentColor.
function Icon({ name, size = 20, fill = false, stroke = 1.8, style, className }) {
  const path = I[name] || '';
  return (
    <svg width={size} height={size} viewBox="0 0 24 24"
    className={className}
    fill={fill ? 'currentColor' : 'none'}
    stroke={fill ? 'none' : 'currentColor'}
    strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"
    style={{ flexShrink: 0, ...style }}
    dangerouslySetInnerHTML={{ __html: path }} />);

}

function Badge({ type }) {
  const t = (type || 'UNKNOWN').toLowerCase();
  return <span className={`badge ${t}`}>{type}</span>;
}

// status pill: over | warn | ok
function StatusPill({ kind, children }) {
  const label = children || (kind === 'over' ? 'Maintenance Due' : kind === 'warn' ? 'Due Soon' : 'Airworthy');
  return (
    <span className={`pill ${kind}`}>
      <span className="pdot" />{label}
    </span>);

}

function Dot({ kind, cls = 'craft-dot' }) {
  return <span className={`${cls} ${kind}`} />;
}

// segmented control
function Segmented({ options, value, onChange }) {
  return (
    <div className="seg">
      {options.map((o) =>
      <button key={o.value} className={`seg-btn ${value === o.value ? 'active' : ''}`} onClick={() => onChange(o.value)}>
          {o.icon && <Icon name={o.icon} size={15} />}
          {o.label}
          {o.count != null && <span className="seg-count">{o.count}</span>}
        </button>
      )}
    </div>);

}

function Toggle({ on, onClick }) {
  return <div className={`toggle ${on ? 'on' : ''}`} onClick={onClick} role="switch" aria-checked={on} />;
}

function Check({ on }) {
  return <div className={`check ${on ? 'on' : ''}`}>{on && <Icon name="check" size={14} stroke={2.4} />}</div>;
}

// portal-free overlay that locks nothing; closes on scrim click
function Drawer({ title, badge, onClose, children, footer }) {
  useEffect(() => {
    const h = (e) => {if (e.key === 'Escape') onClose();};
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, []);
  return (
    <>
      <div className="scrim" onClick={onClose} />
      <aside className="drawer" role="dialog" aria-modal="true">
        <div className="drawer-h">
          {badge}
          <div style={{ flex: 1, fontFamily: 'var(--font-head)', fontWeight: 700, fontSize: 16 }}>{title}</div>
          <button className="icon-btn" style={{ width: 36, height: 36 }} onClick={onClose} aria-label="Close">
            <Icon name="x" size={18} />
          </button>
        </div>
        <div className="drawer-body">{children}</div>
        {footer && <div className="drawer-foot">{footer}</div>}
      </aside>
    </>);

}

function Modal({ title, onClose, children, footer, tabs }) {
  useEffect(() => {
    const h = (e) => {if (e.key === 'Escape') onClose();};
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, []);
  return (
    <div className="modal-wrap">
      <div className="scrim" onClick={onClose} />
      <div className="modal" role="dialog" aria-modal="true" style={{ position: 'relative', zIndex: 1 }}>
        <div className="modal-h">
          <div className="modal-title" style={{ flex: 1 }}>{title}</div>
          <button className="icon-btn" style={{ width: 36, height: 36 }} onClick={onClose} aria-label="Close">
            <Icon name="x" size={18} />
          </button>
        </div>
        {tabs}
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
    </div>);

}

function EmptyState({ icon = 'doc', title, sub }) {
  return (
    <div className="empty">
      <div className="empty-ico"><Icon name={icon} size={26} /></div>
      <div style={{ fontWeight: 600, fontSize: 15, color: 'var(--on-surface)' }}>{title}</div>
      {sub && <div style={{ fontSize: 13, maxWidth: '34ch' }}>{sub}</div>}
    </div>);

}

Object.assign(window, { Icon, Badge, StatusPill, Dot, Segmented, Toggle, Check, Drawer, Modal, EmptyState });