// WingsLog Theme — shared tokens for all UI kit components
const WL_THEME = {
  colors: {
    primary: '#1A5FAE',
    onPrimary: '#FFFFFF',
    primaryContainer: '#D5E3FF',
    onPrimaryContainer: '#001849',
    secondary: '#525E72',
    secondaryContainer: '#D6E4F5',
    tertiary: '#7A5200',
    tertiaryContainer: '#FFDFA6',
    background: '#FAFAFA',
    surface: '#FFFFFF',
    surfaceContainer: '#F2F2F7',
    onSurface: '#1C1C1E',
    onSurfaceVariant: '#636366',
    outline: '#C6C6C8',
    outlineVariant: '#E0E0E5',
    error: '#BA1A1A',
    errorContainer: '#FFDAD6',
    onErrorContainer: '#410002',
    statusOk: '#276B39',
    statusWarning: '#8B5E00',
    statusWarningContainer: '#FFECB3',
  },
  fonts: {
    headline: "'Space Grotesk', system-ui, sans-serif",
    data: "'JetBrains Mono', 'Courier New', monospace",
    body: "system-ui, -apple-system, sans-serif",
  },
  radius: {
    card: '12px',
    button: '16px',
    chip: '12px',
    badge: '4px',
  },
  spacing: {
    xs: '4px', sm: '8px', md: '12px', lg: '16px', xl: '24px', huge: '32px',
  },
};

// Export to global scope
Object.assign(window, { WL_THEME });
