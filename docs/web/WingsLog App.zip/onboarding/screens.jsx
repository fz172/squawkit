// Hopply onboarding screens — Login, NameEntry, Welcome, Dashboard

const { useState, useEffect, useRef } = React;

// ─── Shared tokens ─────────────────────────────────────────────────────
const NAVY = {
  bg:      '#0A2050',
  bgDeep:  '#071740',
  surface: 'rgba(255,255,255,0.06)',
  surfaceHi: 'rgba(255,255,255,0.10)',
  outline: 'rgba(255,255,255,0.14)',
  primary: '#A7C8FF',
  primaryInk: '#0A2050',
  ink:     '#FFFFFF',
  inkMute: 'rgba(255,255,255,0.62)',
  inkDim:  'rgba(255,255,255,0.42)',
};
const DASH = {
  bg:       '#000000',
  card:     '#161618',
  ink:      '#FFFFFF',
  inkMute:  'rgba(255,255,255,0.62)',
  inkDim:   'rgba(255,255,255,0.4)',
  outline:  'rgba(255,255,255,0.07)',
};
const HEADLINE = "'Space Grotesk', system-ui, sans-serif";

// ─── Screen 1: Login ───────────────────────────────────────────────────
function LoginScreen({ onContinue, accent = '#2A6BC9' }) {
  return (
    <div style={{
      position: 'relative',
      height: '100%', background: NAVY.bg,
      display: 'flex', flexDirection: 'column',
      padding: '76px 28px 36px',
      overflow: 'hidden',
    }}>
      {/* soft horizon glow */}
      <div style={{
        position: 'absolute', left: '50%', top: 240, width: 480, height: 480,
        transform: 'translate(-50%, -50%)',
        background: `radial-gradient(circle, ${accent}33 0%, transparent 60%)`,
        pointerEvents: 'none',
      }} />

      {/* Plane mark — slightly tilted, bobbing */}
      <div style={{
        position: 'relative', display: 'flex', justifyContent: 'center',
        marginTop: 32, marginBottom: 8,
      }}>
        <HopplyPlane size={210} color={accent} glow />
      </div>

      {/* Spacer pushes content to bottom half */}
      <div style={{ flex: 1 }} />

      {/* Wordmark */}
      <div style={{ marginBottom: 14 }}>
        <h1 style={{
          fontFamily: HEADLINE, fontWeight: 700,
          fontSize: 44, lineHeight: '46px', letterSpacing: '-1px',
          color: NAVY.ink, margin: 0,
        }}>
          hopply<span style={{ color: NAVY.primary }}>.</span>
        </h1>
        <div style={{
          fontFamily: HEADLINE, fontWeight: 500,
          fontSize: 16, lineHeight: '22px', color: NAVY.inkMute,
          marginTop: 6, maxWidth: 280,
        }}>
          Keep track of the important stuff for your airplane.
        </div>
      </div>

      <div style={{
        fontFamily: 'system-ui, sans-serif', fontSize: 13.5,
        lineHeight: '20px', color: NAVY.inkDim, marginBottom: 20, maxWidth: 320,
      }}>
        Log in or continue anonymously to manage your aircraft maintenance records.
      </div>

      {/* Buttons */}
      <button onClick={onContinue}
        style={{
          width: '100%', height: 54, borderRadius: 16,
          background: '#F2F4F8', border: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12,
          fontFamily: HEADLINE, fontSize: 16, fontWeight: 600,
          color: '#1C1C1E', marginBottom: 12,
          boxShadow: '0 6px 20px rgba(0,0,0,0.18)',
        }}
      >
        <GoogleG />
        Log in with Google
      </button>
      <button onClick={onContinue} style={{
        width: '100%', height: 54, borderRadius: 16,
        background: 'transparent', border: `1.5px solid ${NAVY.outline}`,
        color: NAVY.ink, cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
        fontFamily: HEADLINE, fontSize: 16, fontWeight: 600,
      }}>
        <PersonIcon /> Continue Anonymously
      </button>

      <div style={{
        fontFamily: 'system-ui, sans-serif', fontSize: 11.5,
        lineHeight: '17px', color: NAVY.inkDim, marginTop: 18, textAlign: 'center',
      }}>
        Hopply is a personal convenience tool and is not a certified maintenance record system.
        It does not replace official aircraft logbooks required by your aviation authority.
      </div>
    </div>
  );
}

// ─── Screen 2: Name entry ──────────────────────────────────────────────
function NameEntryScreen({ name, setName, onBack, onNext, accent = '#2A6BC9' }) {
  const inputRef = useRef(null);
  useEffect(() => { inputRef.current && inputRef.current.focus(); }, []);
  const canContinue = name.trim().length >= 1;

  return (
    <div style={{
      position: 'relative', height: '100%', background: NAVY.bg,
      display: 'flex', flexDirection: 'column',
      padding: '76px 28px 0', overflow: 'hidden',
    }}>

      {/* soft horizon glow — spotlight under the input box */}
      <div style={{
        position: 'absolute', left: '50%', top: 540, width: 480, height: 480,
        transform: 'translate(-50%, -50%)',
        background: `radial-gradient(circle, ${accent}33 0%, transparent 60%)`,
        pointerEvents: 'none',
      }} />

      {/* Back chip */}
      <button onClick={onBack} style={{
        position: 'absolute', top: 70, left: 18,
        width: 40, height: 40, borderRadius: 999,
        background: NAVY.surface, border: `1px solid ${NAVY.outline}`,
        color: NAVY.ink, display: 'grid', placeItems: 'center', cursor: 'pointer',
      }}>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M19 12H5M12 19l-7-7 7-7"/>
        </svg>
      </button>

      {/* Step indicator removed per design */}

      {/* Small plane peeking */}
      <div style={{ display: 'flex', justifyContent: 'center', marginTop: 14, marginBottom: 8 }}>
        <HopplyPlane size={108} color={accent} anim="bob" />
      </div>

      <div>
        <div style={{
          fontFamily: 'system-ui, sans-serif', fontSize: 11.5, fontWeight: 700,
          letterSpacing: '1.5px', textTransform: 'uppercase',
          color: NAVY.primary, marginBottom: 8,
        }}>Quick hello</div>
        <h2 style={{
          fontFamily: HEADLINE, fontWeight: 700,
          fontSize: 30, lineHeight: '34px', letterSpacing: '-0.5px',
          color: NAVY.ink, margin: 0,
        }}>
          What should we<br/>call you?
        </h2>
        <div style={{
          fontFamily: 'system-ui, sans-serif', fontSize: 14,
          lineHeight: '20px', color: NAVY.inkMute, marginTop: 10, maxWidth: 300,
        }}>
          Just so we know who's logging this maintenance. You can change it anytime in Settings.
        </div>
      </div>

      {/* Text field */}
      <div style={{ marginTop: 28 }}>
        <label style={{
          display: 'block',
          fontFamily: 'system-ui, sans-serif', fontSize: 11, fontWeight: 600,
          letterSpacing: '0.8px', textTransform: 'uppercase',
          color: NAVY.inkDim, marginBottom: 8, paddingLeft: 4,
        }}>Your name</label>
        <div style={{
          position: 'relative',
          background: NAVY.surface, border: `1.5px solid ${name ? NAVY.primary : NAVY.outline}`,
          borderRadius: 16, padding: '4px 16px',
          transition: 'border-color 0.18s ease',
        }}>
          <input
            ref={inputRef}
            value={name} onChange={e => setName(e.target.value)}
            placeholder="e.g. Pat"
            maxLength={32}
            style={{
              width: '100%', height: 50, background: 'transparent',
              border: 'none', outline: 'none',
              fontFamily: HEADLINE, fontSize: 20, fontWeight: 600,
              color: NAVY.ink, letterSpacing: '-0.3px',
            }}
          />
        </div>
        <div style={{
          fontFamily: 'system-ui, sans-serif', fontSize: 12,
          color: NAVY.inkDim, marginTop: 8, paddingLeft: 4,
        }}>
          Used only on this device — never sent anywhere.
        </div>
      </div>

      {/* Continue */}
      <div style={{ flex: 1 }} />
      <button
        onClick={canContinue ? onNext : undefined}
        disabled={!canContinue}
        style={{
          width: '100%', height: 54, borderRadius: 16,
          background: canContinue ? NAVY.primary : 'rgba(167,200,255,0.18)',
          color: canContinue ? NAVY.primaryInk : NAVY.inkDim,
          border: 'none', cursor: canContinue ? 'pointer' : 'not-allowed',
          fontFamily: HEADLINE, fontSize: 16, fontWeight: 700,
          letterSpacing: '-0.2px', marginBottom: 24,
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          transition: 'background 0.18s ease, color 0.18s ease',
        }}
      >
        Continue
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
          <path d="M5 12h14M12 5l7 7-7 7"/>
        </svg>
      </button>
    </div>
  );
}

// ─── Screen 3: Welcome animation ───────────────────────────────────────
function WelcomeScreen({ name, onDone, accent = '#2A6BC9' }) {
  const [phase, setPhase] = useState(0); // 0 plane flying, 1 name reveal, 2 sit
  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 900);
    const t2 = setTimeout(() => setPhase(2), 1800);
    const t3 = setTimeout(() => onDone(), 2900);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [onDone]);

  return (
    <div style={{
      position: 'relative', height: '100%',
      background: NAVY.bg,
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      justifyContent: 'center', padding: '40px 28px', overflow: 'hidden',
    }}>

      {/* soft horizon glow — spotlight under the welcome name */}
      <div style={{
        position: 'absolute', left: '50%', top: 560, width: 480, height: 480,
        transform: 'translate(-50%, -50%)',
        background: `radial-gradient(circle, ${accent}33 0%, transparent 60%)`,
        pointerEvents: 'none',
      }} />

      {/* Plane swooping up */}
      <div style={{
        position: 'absolute', left: '50%', top: '50%',
        transform: 'translate(-50%, -50%)',
        zIndex: 2,
      }}>
        <div style={{
          position: 'relative', width: 240, height: 240,
        }}>
          <div style={{
            position: 'absolute', inset: 0,
            opacity: phase < 1 ? 1 : 0,
            transition: 'opacity 0.4s ease',
          }}>
            <div style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%, -50%)' }}>
              <HopplyPlane size={150} color={accent} anim="fly" glow />
            </div>
          </div>
        </div>
      </div>

      {/* Welcome copy */}
      <div style={{
        position: 'relative', zIndex: 3, textAlign: 'center',
        opacity: phase >= 1 ? 1 : 0,
        transform: phase >= 1 ? 'translateY(0)' : 'translateY(10px)',
        transition: 'opacity 0.5s ease, transform 0.5s cubic-bezier(.22,1,.36,1)',
      }}>
        <div style={{
          fontFamily: HEADLINE, fontWeight: 600, fontSize: 17,
          color: NAVY.primary, letterSpacing: '0.5px', marginBottom: 10,
        }}>
          Welcome aboard
        </div>
        <h1 style={{
          fontFamily: HEADLINE, fontWeight: 700,
          fontSize: 44, lineHeight: '48px', letterSpacing: '-1px',
          color: NAVY.ink, margin: 0,
        }}>
          {name.trim() || 'aboard'} <span style={{ display: 'inline-block', animation: 'wave 1.2s ease-in-out infinite', transformOrigin: '70% 80%' }}>👋</span>
        </h1>
        <div style={{
          fontFamily: HEADLINE, fontWeight: 500, fontSize: 15,
          color: NAVY.inkMute, marginTop: 14, maxWidth: 280, marginInline: 'auto',
        }}>
          Let's get your hangar set up.
        </div>
      </div>

      {/* Loader pip */}
      <div style={{
        position: 'absolute', bottom: 64, left: 0, right: 0,
        display: 'flex', justifyContent: 'center', gap: 6,
        opacity: phase >= 1 ? 1 : 0, transition: 'opacity 0.4s ease',
      }}>
        {[0,1,2].map(i => (
          <div key={i} style={{
            width: 6, height: 6, borderRadius: 999, background: NAVY.primary,
            animation: `loader-dot 1.1s ease-in-out ${i*0.15}s infinite`,
          }}/>
        ))}
      </div>

      <style>{`
        @keyframes wave {
          0%, 100% { transform: rotate(0deg); }
          25%      { transform: rotate(18deg); }
          75%      { transform: rotate(-12deg); }
        }
        @keyframes loader-dot {
          0%, 100% { opacity: 0.3; transform: translateY(0); }
          50%      { opacity: 1;   transform: translateY(-4px); }
        }
      `}</style>
    </div>
  );
}

// ─── Screen 4: Dashboard (light placeholder) ───────────────────────────
function timeGreeting(d = new Date()) {
  const h = d.getHours();
  if (h < 5)  return 'Good evening';
  if (h < 12) return 'Good morning';
  if (h < 18) return 'Good afternoon';
  return 'Good evening';
}

const AIRCRAFT = [
  { model: 'SoroSuub N-1 Scout',       tail: 'N7623C', status: 'OVERDUE' },
  { model: 'Another airplane Cool Beans', tail: 'HEHE', status: null      },
  { model: 'Cessna 172SP',             tail: 'N123AA', status: 'DUE'     },
  { model: 'Sling TSi',                tail: 'N532SL', status: null      },
];

function DashboardScreen({ name, onLogout, accent = '#2A6BC9' }) {
  const greeting = timeGreeting();
  const overdueCount = AIRCRAFT.filter(a => a.status === 'OVERDUE').length;
  const displayName = (name || '').trim() || 'Pat';

  return (
    <div style={{
      height: '100%', background: DASH.bg, overflow: 'auto',
      paddingBottom: 24, position: 'relative',
    }}>
      {/* Action bar — greeting + overdue summary */}
      <div style={{
        padding: '72px 22px 20px 22px',
        display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12,
      }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            fontFamily: HEADLINE, fontSize: 13, fontWeight: 600,
            color: DASH.inkMute, letterSpacing: '0.3px',
          }}>
            {greeting},
          </div>
          <h1 style={{
            fontFamily: HEADLINE, fontWeight: 700,
            fontSize: 32, lineHeight: '36px', letterSpacing: '-0.5px',
            color: DASH.ink, margin: '2px 0 0',
          }}>{displayName}</h1>
        </div>

        {/* Avatar / settings button */}
        <button aria-label="Settings" style={{
          marginTop: 10, flexShrink: 0,
          width: 44, height: 44, borderRadius: 999,
          background: 'linear-gradient(135deg, #C49B5A 0%, #A0673A 45%, #C46A4A 100%)',
          backgroundBlendMode: 'overlay',
          border: '1.5px solid rgba(255,255,255,0.12)',
          cursor: 'pointer', padding: 0,
          display: 'grid', placeItems: 'center',
          fontFamily: HEADLINE, fontWeight: 700, fontSize: 15,
          color: 'rgba(0,0,0,0.55)', letterSpacing: 0,
          overflow: 'hidden', position: 'relative',
        }}>
          <span style={{ position: 'relative', zIndex: 1 }}>
            {displayName.charAt(0).toUpperCase()}
          </span>
          {/* impasto / painterly texture */}
          <span style={{
            position: 'absolute', inset: 0, opacity: 0.55, pointerEvents: 'none',
            background:
              'radial-gradient(circle at 30% 20%, #FFE082 0%, transparent 35%),' +
              'radial-gradient(circle at 70% 70%, #4A1F0E 0%, transparent 38%),' +
              'radial-gradient(circle at 80% 25%, #9E8C00 0%, transparent 30%),' +
              'radial-gradient(circle at 25% 75%, #2D5BA8 0%, transparent 32%)',
          }}/>
        </button>
      </div>

      {/* Aircraft cards */}
      <div style={{ padding: '4px 16px 0', display: 'flex', flexDirection: 'column', gap: 14 }}>
        {AIRCRAFT.map(a => <AircraftCard key={a.tail} {...a} accent={accent}/>)}
      </div>

      {/* FAB */}
      <button aria-label="Add aircraft" style={{
        position: 'absolute', bottom: 30, right: 22,
        width: 56, height: 56, borderRadius: 18,
        background: accent, border: 'none', cursor: 'pointer',
        display: 'grid', placeItems: 'center',
        boxShadow: `0 12px 28px ${accent}45, 0 4px 8px rgba(0,0,0,0.4)`,
      }}>
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#0A2050" strokeWidth="2.4" strokeLinecap="round">
          <path d="M12 5v14M5 12h14"/>
        </svg>
      </button>
    </div>
  );
}

function AircraftCard({ model, tail, status, accent = '#5FA3FF' }) {
  const badge = status === 'OVERDUE' ? { label: 'Maintenance Due', bg: '#7A1B17', fg: '#FFE5E2' }
              : status === 'DUE'     ? { label: 'Maintenance Due', bg: '#5A4400', fg: '#FFD66B' }
              : null;
  return (
    <div style={{
      background: DASH.card,
      border: `1px solid ${DASH.outline}`,
      borderRadius: 18,
      padding: '20px 18px 22px',
      display: 'flex', alignItems: 'center', gap: 12,
    }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap',
          marginBottom: 10,
        }}>
          <div style={{
            fontFamily: HEADLINE, fontWeight: 700,
            fontSize: 22, lineHeight: '26px', letterSpacing: '-0.3px',
            color: DASH.ink,
          }}>{model}</div>
          {badge && (
            <span style={{
              fontFamily: 'system-ui, sans-serif', fontSize: 12, fontWeight: 600,
              padding: '4px 10px', borderRadius: 6,
              background: badge.bg, color: badge.fg, whiteSpace: 'nowrap',
            }}>{badge.label}</span>
          )}
        </div>
        <div style={{
          fontFamily: "'JetBrains Mono', monospace", fontSize: 14,
          fontWeight: 500, color: accent, letterSpacing: '0.3px',
        }}>{tail}</div>
      </div>
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
        stroke="rgba(255,255,255,0.35)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="9 18 15 12 9 6"/>
      </svg>
    </div>
  );
}

// ─── Atoms ─────────────────────────────────────────────────────────────
function GoogleG() {
  return (
    <svg width="20" height="20" viewBox="0 0 18 18">
      <path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844a4.14 4.14 0 01-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.875 2.684-6.615z" fill="#4285F4"/>
      <path d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 009 18z" fill="#34A853"/>
      <path d="M3.964 10.71A5.41 5.41 0 013.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 000 9c0 1.452.348 2.827.957 4.042l3.007-2.332z" fill="#FBBC05"/>
      <path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 00.957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z" fill="#EA4335"/>
    </svg>
  );
}
function PersonIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="8" r="4"/>
      <path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"/>
    </svg>
  );
}

Object.assign(window, {
  LoginScreen, NameEntryScreen, WelcomeScreen, DashboardScreen,
});
