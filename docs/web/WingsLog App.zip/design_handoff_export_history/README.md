# Handoff: Export History Screen

## Overview
The **Export History** screen lists previously-generated log exports for the Hopply (WingsLog) maintenance logbook app. Each row represents a ZIP archive of maintenance logs (the report formats inside vary: PDF, CSV, XLSX). The user can tap a card's ⋮ to open a contextual menu that adapts to the export's state (whether the user has an email on file, and whether the file is on device / in cloud / both).

This screen is reached from the Export setup screen (via the history icon in the top app bar) and from the success result screen (via "View exports").

## About the Design Files
**These files are a design reference created in HTML — not production code.** They demonstrate intended look, layout, and behavior using React 18 + inline Babel JSX inside a single HTML page, with hand-rolled styles. Material Symbols come from Google Fonts at runtime; Space Grotesk and JetBrains Mono are bundled as `.ttf` files.

The task is to **recreate this design in the target codebase's environment** — for Hopply that means **Kotlin Multiplatform Mobile (KMM) with Compose Multiplatform**, sharing UI between Android and iOS. Use Compose's existing patterns (`Card`, `DropdownMenu`, `Icon`, `Text`) and the existing `core/ui/` design tokens. Don't copy the HTML literally.

## Fidelity
**High-fidelity.** Exact colors, typography, spacing, border radii, icon names, and interaction states are specified below and visible in `ExportHistory.html`. Match precisely; the design system this lives within is deliberate and unified across the app (instrument-blue palette, two distinct font families with semantic roles).

## How to run the reference
1. Serve the `design_handoff_export_history/` folder over a local HTTP server (e.g. `python3 -m http.server`) — fonts require a real origin.
2. Open `ExportHistory.html` in any modern browser.
3. The screen renders inside a faux iOS device frame at 402×874. Click any card's ⋮ button to open its menu; click outside or press Esc to dismiss.

---

## The Screen

### Name
`ExportHistoryScreen`

### Purpose
Browse and act on previously-generated log exports. Common actions per export:
- **Resend** the export email
- **Share** the local file via the system share sheet
- **Save** a cloud-only export back to this device
- **Delete** the export

### Top-level layout
- Background: solid `#000000` (`EX.bg`)
- Sticky top app bar at the top of the screen
- Vertical scroll region below, padded `4px 16px 24px`
- Cards in a `flex column` with `gap: 10px`
- Empty state (when there are no exports): centered icon + headline + body + primary button

### Top app bar
- Sticky, `position: sticky; top: 0; z-index: 4`
- Background: `EX.bg`
- Padding: `60px 20px 14px 8px` (top padding accounts for status bar inset)
- Layout: `flex` row, `align: center`, `gap: 4`
- Back button: 44×44 circular ripple target, `arrow_back` Material Symbol at 24px in `EX.ink`
- Title: "Export history" in **Space Grotesk 700**, 26px / 30px line-height, letter-spacing `-0.4px`, color `EX.ink`

---

## Cards (`HistoryCard`)

### Container
- Background: `#161618` (`EX.surface`)
- Border: 1px solid `rgba(255,255,255,0.08)` (default) / `rgba(255,255,255,0.14)` when its menu is open
- Border radius: **14px**
- Padding: **14px** all sides
- Layout: `flex` row, `align: center`, `gap: 12px`
- `position: relative` (anchors the popover menu)
- `z-index: 5` while its own menu is open (so the popover floats above sibling cards)
- `transition: border-color 0.15s ease`

### Leading icon (ZIP indicator)
- 44×44 square, **border radius 12px**
- Background: `rgba(167,200,255,0.12)` (primary-blue tint at 12% alpha)
- Centered Material Symbol: `folder_zip`, **size 22**, color `EX.primary` (`#A7C8FF`), **filled** (`FILL: 1`)

### Text block (middle, flex: 1)
Three lines, all left-aligned:

**Line 1 — aircraft tail(s)**
- `font-family: JetBrains Mono` (semantic: tail numbers are technical data)
- `font-weight: 700`, `font-size: 14px`, `letter-spacing: 0.3px`
- Color: `EX.ink` (`#FFFFFF`)
- Margin-bottom: 3px
- For multi-aircraft exports: `"{firstTail} +{n-1}"` (e.g. `N2098U +1`)

**Line 2 — formats + date range**
- `font-family: system-ui, -apple-system, sans-serif` (`F.body`)
- `font-size: 12.5px`, `line-height: 17px`
- Color: `rgba(255,255,255,0.62)` (`EX.inkMute`)
- Ellipsis on overflow (`white-space: nowrap`)
- Content: `{formats joined} · {rangeLabel}` (e.g. `PDF, CSV + XLSX · All time`)
- Separator is `·` (middle dot) at `rgba(255,255,255,0.4)` (`EX.inkDim`)
- Format join rule: 1 item → as is; 2 items → `A + B`; 3+ items → `A, B + C`

**Line 3 — when / size / sync chip**
- `font-family: system-ui, …` (`F.body`)
- `font-size: 11.5px`, color: `EX.inkDim` (`rgba(255,255,255,0.4)`)
- `flex` row with `gap: 6`, `flex-wrap: wrap`
- Sequence: `{when} · {size}` and, if the sync chip is not `null`, `· {chip}`
- Margin-top: 3px

### Sync state chip (inline on line 3)
Single source of truth: `SYNC_STATES` in `history-screen.jsx`.

| State    | Chip text   | Icon              | Color       | Tint background        |
|----------|-------------|-------------------|-------------|------------------------|
| `synced` | *(none)*    | *(none)*          | *(none)*    | *(none)*               |
| `cloud`  | `In cloud`  | `cloud` (filled)  | `#9FB6D9`   | `rgba(159,182,217,0.10)` |
| `local`  | `On device` | `phone_iphone` (filled) | `#C9A961` | `rgba(201,169,97,0.10)` |

**Why `synced` has no chip:** synced is the happy path / most common state. Absence of chrome = OK. Adding a "Synced ✓" badge to every row would create visual noise on the common case.

**Why these specific colors:**
- `cloud` uses a desaturated cool blue (`#9FB6D9`) — informational, no urgency
- `local` uses a desaturated warm amber (`#C9A961`) — mild "not backed up" warning, but not a hard error

The chip is inline text with a 12px filled icon ahead of it, in the same color. Implementation:
```jsx
<span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, color: sync.color }}>
  <MSym name={sync.icon} size={12} color={sync.color} fill={1} />
  {sync.chip}
</span>
```

### Trailing overflow button
- 36×36, border-radius 10px
- Background: `transparent` (default) / `rgba(255,255,255,0.08)` (active/menu-open)
- Color: `EX.inkMute` (default) / `EX.ink` (active)
- Material Symbol: `more_vert`, size 20
- `aria-label="More actions"`, `aria-haspopup="menu"`, `aria-expanded={menuOpen}`
- Click toggles its own menu open; clicking it when open closes it
- `e.stopPropagation()` on click — prevents document-level outside-click from immediately re-closing it

---

## Popover menu

### Container
- `position: absolute`, anchored to the card
- `top: calc(100% + 6px)`, `right: 8px` — flows down-right from the overflow button
- `min-width: 200px`
- Background: `#1F1F22` (`EX.surfaceHi`) — one step lighter than the card surface so it visually pops
- Border: 1px solid `EX.outlineHi` (`rgba(255,255,255,0.14)`)
- Border radius: **12px**
- Padding: **6px**
- Box shadow: `0 8px 28px rgba(0,0,0,0.55), 0 2px 6px rgba(0,0,0,0.35)` — two-layer drop shadow for depth on dark surface
- `z-index: 10`
- `transform-origin: top right`
- Enter animation: `hopplyMenuIn 0.14s ease-out` — scales from 0.96 + translateY(-4px) to identity, fade in

### Items (`MenuItem`)
- Full-width button, `flex` row, `align: center`, `gap: 12px`
- Padding: **10px 12px**
- Border radius: **8px**
- Background: `transparent` (default), `rgba(255,255,255,0.06)` on hover (non-destructive), `rgba(255,107,107,0.10)` on hover (destructive)
- `font-family: F.body`, `font-size: 14px`, `font-weight: 500`
- Color: `EX.ink` (`#FFFFFF`) for normal items, `#FF6B6B` (`EX.err`) for the destructive Delete item
- Icon: leading Material Symbol at 18px, color matching the item text
- `transition: background 0.12s ease`
- `role="menuitem"`

### Separator
- 1px high, color `EX.outline`, margin `6px 4px`
- Placed between non-destructive items and the destructive Delete

### Conditional item visibility — **THIS IS THE CRITICAL LOGIC**

The four candidate items are filtered based on the export's `(hasEmail, syncState)`:

| Menu item         | Show when                                              | Hidden when                                  |
|-------------------|--------------------------------------------------------|----------------------------------------------|
| **Resend email**  | `hasEmail && (syncState === 'synced' \|\| 'cloud')`     | no email on file, OR file is local-only      |
| **Share file**    | `syncState === 'synced' \|\| 'local'`                   | file is cloud-only (nothing on device to share) |
| **Save to device**| `syncState === 'cloud'`                                | already on device                            |
| **Delete export** | always                                                 | never                                        |

Rationale:
- **Resend** sends the existing cloud copy back to the user's email — so it requires both a recipient (`hasEmail`) and a source (cloud copy exists)
- **Share** invokes the OS share sheet on a local file — only possible if the file is on this device
- **Save to device** downloads the cloud copy locally — only offered when the file isn't already here
- **Delete** removes both copies (or whichever exists)

In Compose, this is straightforward: build a list of menu options based on the state and pass it to a `DropdownMenu`. Don't render hidden items at all (no greyed-out placeholders).

### Demo matrix (visible in the mock)
Four cards in `HISTORY_ITEMS` cover all four meaningful `(hasEmail, syncState)` combinations:

| ID  | hasEmail | syncState | Menu contents               | Chip          |
|-----|----------|-----------|-----------------------------|---------------|
| h1  | ✓        | synced    | Resend · Share · Delete     | *(none)*      |
| h2  | ✓        | cloud     | Resend · Save · Delete      | ☁ In cloud    |
| h3  | —        | local     | Share · Delete              | 📱 On device  |
| h4  | —        | cloud     | Save · Delete               | ☁ In cloud    |

The 5th combination (`hasEmail=true, syncState=local`) is also possible (cloud copy expired, file still on device) — menu would be Share + Delete.

### Dismissal
- Click anywhere outside the menu (and outside the trigger button) → closes
- Press `Escape` → closes
- Clicking another card's overflow button → closes the current menu and opens the new one
  (achieved by lifting `openMenuId` state to the parent screen, not the card)

---

## Behavior & State

### State owned by `ExportHistoryScreen`
- `openMenuId: string | null` — which card's menu is currently open. Defaulted to `'h1'` in the mock so the menu is visible on first paint; in production, default to `null`.

### State owned by each `HistoryCard`
- `menuRef`, `btnRef` — refs to the popover container and the trigger button. Used for outside-click detection (an event is "outside" if it hits neither).

### Effects
- A `mousedown` listener on `document` while the menu is open detects outside clicks
- A `keydown` listener detects Escape
- Both are cleaned up in the effect's return

### Actions
In the mock, action handlers just `console.log` and close the menu. In production, wire them to:
- **Resend email** → POST to your existing export-resend endpoint, show a snackbar on success ("Email sent")
- **Share file** → invoke the system share sheet with the local ZIP file URI
- **Save to device** → download the cloud copy to device storage, show progress, show snackbar on completion
- **Delete export** → show a confirmation dialog ("Delete this export? This cannot be undone."), then delete on confirm; remove the card from the list

### Empty state
When `HISTORY_ITEMS` is empty:
- Centered `inbox` Material Symbol at 56px in `EX.inkDim`
- 14px margin
- Headline: "No exports yet" — Space Grotesk 700, 22px, `EX.ink`
- Body: "Generate a printable PDF or spreadsheet of your maintenance logs to share with your mechanic, IA, or insurance." — F.body 14px, `EX.inkMute`, max-width 280px
- 22px margin
- Primary button: "New export" — padding 12px 22px, radius 14px, background `EX.primary`, text `EX.primaryInk`, Space Grotesk 700 / 14.5px

---

## Design Tokens

All tokens live in `EX` and `F` in `history-screen.jsx`. These align with the WingsLog design system in `core/ui/`.

### Colors
```
EX.bg          #000000                       Screen background
EX.surface     #161618                       Card background
EX.surfaceHi   #1F1F22                       Menu popover background (one step up)
EX.outline     rgba(255,255,255,0.08)        Card border (default)
EX.outlineHi   rgba(255,255,255,0.14)        Card border (menu open), menu border
EX.primary     #A7C8FF                       Primary (Garmin G1000 avionics blue, dark)
EX.primaryInk  #0A2050                       Foreground on EX.primary surfaces
EX.ink         #FFFFFF                       Primary text
EX.inkMute     rgba(255,255,255,0.62)        Secondary text
EX.inkDim      rgba(255,255,255,0.4)         Tertiary text / separators
EX.ok          #81C784                       Success (unused on this screen)
EX.warn        #FFCA28                       Caution (unused on this screen)
EX.err         #FF6B6B                       Destructive (Delete menu item)

Cloud chip     #9FB6D9                       "In cloud" — desaturated cool blue
Local chip     #C9A961                       "On device" — desaturated warm amber
```

### Typography
```
F.headline   'Space Grotesk', system-ui, sans-serif
F.data       'JetBrains Mono', 'Courier New', monospace
F.body       system-ui, -apple-system, sans-serif
```
- **Space Grotesk** — all headlines, top bar title, primary button labels. Weights 500 / 600 / 700.
- **JetBrains Mono** — tail numbers ONLY on this screen. The mono treatment is semantic (technical data alignment).
- **System** — everything else (body copy, menu items, metadata).

### Spacing scale (used here)
```
3, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 60
```
These are subset of the design system's `2 · 4 · 8 · 12 · 16 · 24 · 32 · 48` scale, with a few in-between values for the dense card metadata.

### Border radii
```
Card           14
Menu popover   12
Menu item      8
ZIP icon tile  12
Overflow btn   10
```

### Shadows
```
Menu popover   0 8px 28px rgba(0,0,0,0.55), 0 2px 6px rgba(0,0,0,0.35)
```
Cards themselves have no shadow — borders define containment, per the design system.

---

## Assets

### Icons (Material Symbols Outlined, variable axes `FILL` + `wght`)
| Icon name        | Used for                       |
|------------------|--------------------------------|
| `arrow_back`     | Top bar back button            |
| `folder_zip`     | Card leading icon              |
| `cloud`          | "In cloud" sync chip           |
| `phone_iphone`   | "On device" sync chip          |
| `more_vert`      | Overflow trigger               |
| `mail`           | Menu: Resend email             |
| `ios_share`      | Menu: Share file               |
| `download`       | Menu: Save to device           |
| `delete`         | Menu: Delete export            |
| `inbox`          | Empty state                    |

In Compose, use `androidx.compose.material.icons.Icons.Default.*` for the matches and `androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowBack` for the back arrow (auto-mirrors for RTL).

### Fonts
Bundled in `fonts/`:
- `space_grotesk_medium.ttf` (500)
- `space_grotesk_semibold.ttf` (600)
- `space_grotesk_bold.ttf` (700)
- `jetbrains_mono_medium.ttf` (500)
- `jetbrains_mono_bold.ttf` (700)

In Compose, these should already be registered in your `core/ui/` font resources.

---

## Files in this bundle

| File                       | Purpose                                                          |
|----------------------------|------------------------------------------------------------------|
| `README.md`                | This document                                                    |
| `ExportHistory.html`       | Standalone host page — opens the screen inside an iOS device frame |
| `history-screen.jsx`       | The actual screen + card + menu components, plus tokens & data   |
| `ios-frame.jsx`            | Device-frame chrome (status bar, notch, home indicator) — design scaffolding only, not part of the screen |
| `fonts/`                   | TTF files for Space Grotesk + JetBrains Mono                     |

Note: `ios-frame.jsx` exists only to give the design realistic phone-shaped framing in the browser preview. It is NOT part of the screen and should not be ported.

---

## Implementation checklist for Claude Code

When porting to Compose Multiplatform:

- [ ] Reuse the existing top app bar component from `core/ui/TopBar.kt` — match title "Export history" and back behavior
- [ ] Build `HistoryCard` as a `Card(onClick = …)` with internal padding 14dp, corner radius 12dp (the closest design-system value to the mock's 14px), 1dp `outlineVariant` border
- [ ] Two text styles: `JetBrains Mono Bold` for the tail line, `system` for body lines
- [ ] Inline sync-state chip: small `Row` with `Icon` (size 12dp) + `Text` colored per `SYNC_STATES`
- [ ] Overflow button: `IconButton` with `Icons.Default.MoreVert`, opens a `DropdownMenu`
- [ ] Menu items: `DropdownMenuItem` with leading icon; destructive Delete item uses `MaterialTheme.colorScheme.error`
- [ ] Add a `Divider` before the Delete item
- [ ] Conditional rendering: build the list of menu items based on `(hasEmail, syncState)` per the table above; don't render hidden items
- [ ] Wire actions to existing export repository / share intent / file-save logic
- [ ] Confirm Delete via `AlertDialog` ("Delete this export? This cannot be undone.")
- [ ] Empty state: separate composable matching the spec above
- [ ] Test all 5 valid `(hasEmail, syncState)` combinations end-to-end
