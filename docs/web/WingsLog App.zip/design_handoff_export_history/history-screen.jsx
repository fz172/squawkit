// Hopply — Export History screen
// Design tokens, components, and data for the History screen.
// Renders the screen with 4 demo cards showing all three sync states + menu variants.

const { useState, useEffect, useRef } = React;

// ─── Tokens ─────────────────────────────────────────────────────────────
// Matches WingsLog/Hopply design system — dark surfaces, instrument-blue primary.
const EX = {
  bg:        '#000000',
  surface:   '#161618',
  surfaceHi: '#1F1F22',
  outline:   'rgba(255,255,255,0.08)',
  outlineHi: 'rgba(255,255,255,0.14)',
  primary:   '#A7C8FF', // Garmin G1000 avionics blue (dark theme)
  primaryInk:'#0A2050',
  ink:       '#FFFFFF',
  inkMute:   'rgba(255,255,255,0.62)',
  inkDim:    'rgba(255,255,255,0.4)',
  ok:        '#81C784',
  warn:      '#FFCA28',
  err:       '#FF6B6B'
};
const F = {
  headline: "'Space Grotesk', system-ui, sans-serif",
  data:     "'JetBrains Mono', 'Courier New', monospace",
  body:     "system-ui, -apple-system, sans-serif"
};

// Material Symbols helper
function MSym({ name, size = 24, weight = 400, fill = 0, color = 'currentColor', style }) {
  return (
    <span className="material-symbols-outlined" style={{
      fontSize: size, color, lineHeight: 1,
      fontVariationSettings: `'FILL' ${fill}, 'wght' ${weight}, 'GRAD' 0, 'opsz' ${size}`,
      userSelect: 'none', flexShrink: 0,
      ...style
    }}>{name}</span>
  );
}

// ─── Data model ─────────────────────────────────────────────────────────
// Every export is a ZIP; `formats` is the list of report document types inside.
//
// `hasEmail`  — user has email on file (so the Resend option is even possible)
// `syncState` — file location:
//                'synced' (device + cloud), 'cloud' (remote only), 'local' (device only)
const HISTORY_ITEMS = [
  { id: 'h1', formats: ['PDF','CSV','XLSX'], aircraft: ['N2098U','N532SL'],
    rangeLabel: 'All time',         logs: 20, size: '4.9 MB', when: 'Today, 9:57',
    hasEmail: true,  syncState: 'synced' },
  { id: 'h2', formats: ['PDF','XLSX'],       aircraft: ['N532SL'],
    rangeLabel: 'Last 12 months',   logs: 8,  size: '3.1 MB', when: 'May 14',
    hasEmail: true,  syncState: 'cloud'  },
  { id: 'h3', formats: ['PDF'],              aircraft: ['N2098U'],
    rangeLabel: 'Mar 1 – Apr 30',   logs: 6,  size: '2.4 MB', when: 'May 02',
    hasEmail: false, syncState: 'local'  },
  { id: 'h4', formats: ['CSV'],              aircraft: ['N532SL'],
    rangeLabel: 'Annual 2025',      logs: 12, size: '7.1 MB', when: 'Jan 04',
    hasEmail: false, syncState: 'cloud'  },
];

// Sync-state visual spec — single source of truth for inline status chips.
// `synced` is the happy path: no chip is rendered (absence of chrome = OK).
// `cloud` uses cool blue (informational); `local` uses warm amber (not backed up).
const SYNC_STATES = {
  synced: { chip: null,        icon: null,            color: null,      tint: null                          },
  cloud:  { chip: 'In cloud',  icon: 'cloud',         color: '#9FB6D9', tint: 'rgba(159,182,217,0.10)'     },
  local:  { chip: 'On device', icon: 'phone_iphone',  color: '#C9A961', tint: 'rgba(201,169,97,0.10)'      },
};

// ─── Helpers ────────────────────────────────────────────────────────────
const FORMAT_ORDER = ['PDF','CSV','XLSX'];
function orderFormats(input) {
  const set = input instanceof Set ? input : new Set(input || []);
  return FORMAT_ORDER.filter(f => set.has(f));
}
function formatsJoin(arr) {
  if (!arr || arr.length === 0) return '—';
  if (arr.length === 1) return arr[0];
  if (arr.length === 2) return `${arr[0]} + ${arr[1]}`;
  return `${arr.slice(0,-1).join(', ')} + ${arr[arr.length-1]}`;
}

// ─── Top app bar ────────────────────────────────────────────────────────
function TopBar({ title, onBack, trailing }) {
  return (
    <div style={{
      position: 'sticky', top: 0, zIndex: 4,
      background: EX.bg,
      padding: '60px 20px 14px 8px',
      display: 'flex', alignItems: 'center', gap: 4
    }}>
      <button onClick={onBack} aria-label="Back" style={{
        width: 44, height: 44, borderRadius: 999,
        background: 'transparent', border: 'none', cursor: 'pointer',
        color: EX.ink, display: 'grid', placeItems: 'center'
      }}>
        <MSym name="arrow_back" size={24} />
      </button>
      <h1 style={{
        flex: 1, fontFamily: F.headline, fontWeight: 700,
        fontSize: 26, lineHeight: '30px', letterSpacing: '-0.4px',
        color: EX.ink, margin: 0
      }}>{title}</h1>
      {trailing}
    </div>
  );
}

// ─── ExportHistoryScreen ────────────────────────────────────────────────
function ExportHistoryScreen({ onBack, onNew, empty }) {
  // The parent owns "which menu is open" so only one card's menu is visible at a time.
  // Default to h1 open so the menu mock is visible on first paint.
  const [openMenuId, setOpenMenuId] = useState('h1');

  if (empty) {
    return (
      <div style={{ height: '100%', background: EX.bg, display: 'flex', flexDirection: 'column' }}>
        <TopBar title="Export history" onBack={onBack} />
        <div style={{
          flex: 1, display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center',
          textAlign: 'center', padding: '0 32px'
        }}>
          <MSym name="inbox" size={56} color={EX.inkDim} />
          <h3 style={{
            fontFamily: F.headline, fontWeight: 700, fontSize: 22,
            color: EX.ink, margin: '14px 0 6px'
          }}>No exports yet</h3>
          <div style={{
            fontFamily: F.body, fontSize: 14, color: EX.inkMute,
            lineHeight: '20px', maxWidth: 280, marginBottom: 22
          }}>
            Generate a printable PDF or spreadsheet of your maintenance logs to share with your mechanic, IA, or insurance.
          </div>
          <button onClick={onNew} style={{
            padding: '12px 22px', borderRadius: 14,
            background: EX.primary, color: EX.primaryInk,
            border: 'none', cursor: 'pointer',
            fontFamily: F.headline, fontSize: 14.5, fontWeight: 700
          }}>New export</button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ height: '100%', background: EX.bg, display: 'flex', flexDirection: 'column' }}>
      <TopBar title="Export history" onBack={onBack} />

      <div style={{ flex: 1, overflow: 'auto', padding: '4px 16px 24px' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, position: 'relative' }}>
          {HISTORY_ITEMS.map(item => (
            <HistoryCard
              key={item.id}
              item={item}
              menuOpen={openMenuId === item.id}
              onOpenMenu={() => setOpenMenuId(item.id)}
              onCloseMenu={() => setOpenMenuId(null)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── HistoryCard ────────────────────────────────────────────────────────
function HistoryCard({ item, menuOpen, onOpenMenu, onCloseMenu }) {
  const aircraftText = item.aircraft.length === 1
    ? item.aircraft[0]
    : `${item.aircraft[0]} +${item.aircraft.length - 1}`;
  const fmts = orderFormats(item.formats);
  const sync = SYNC_STATES[item.syncState] || SYNC_STATES.synced;
  const isOnDevice = item.syncState === 'synced' || item.syncState === 'local';
  const isInCloud  = item.syncState === 'synced' || item.syncState === 'cloud';

  const menuRef = useRef(null);
  const btnRef  = useRef(null);

  // Click-outside / Esc dismiss
  useEffect(() => {
    if (!menuOpen) return;
    const onDown = e => {
      if (menuRef.current?.contains(e.target)) return;
      if (btnRef.current?.contains(e.target))  return;
      onCloseMenu && onCloseMenu();
    };
    const onKey = e => { if (e.key === 'Escape') onCloseMenu && onCloseMenu(); };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [menuOpen, onCloseMenu]);

  const doAction = label => () => {
    console.log(`[history] ${label} → ${item.id}`);
    onCloseMenu && onCloseMenu();
  };

  return (
    <div style={{
      background: EX.surface,
      border: `1px solid ${menuOpen ? EX.outlineHi : EX.outline}`,
      borderRadius: 14,
      padding: 14,
      display: 'flex', alignItems: 'center', gap: 12,
      position: 'relative',
      zIndex: menuOpen ? 5 : 1,
      transition: 'border-color 0.15s ease'
    }}>
      {/* ZIP icon */}
      <div style={{
        width: 44, height: 44, borderRadius: 12,
        background: 'rgba(167,200,255,0.12)',
        display: 'grid', placeItems: 'center', flexShrink: 0
      }}>
        <MSym name="folder_zip" size={22} color={EX.primary} fill={1} />
      </div>

      <div style={{ flex: 1, minWidth: 0 }}>
        {/* Line 1: tail numbers (mono) */}
        <div style={{
          fontFamily: F.data, fontSize: 14, fontWeight: 700,
          color: EX.ink, letterSpacing: '0.3px', marginBottom: 3
        }}>{aircraftText}</div>

        {/* Line 2: formats + date range */}
        <div style={{
          fontFamily: F.body, fontSize: 12.5, color: EX.inkMute,
          lineHeight: '17px',
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap'
        }}>
          {formatsJoin(fmts)} <span style={{ color: EX.inkDim }}>·</span> {item.rangeLabel}
        </div>

        {/* Line 3: when · size · (optional) sync chip */}
        <div style={{
          marginTop: 3,
          fontFamily: F.body, fontSize: 11.5, color: EX.inkDim,
          display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap'
        }}>
          <span>{item.when}</span>
          <span style={{ opacity: 0.6 }}>·</span>
          <span>{item.size}</span>
          {sync.chip && (
            <>
              <span style={{ opacity: 0.6 }}>·</span>
              <span style={{
                display: 'inline-flex', alignItems: 'center', gap: 4,
                color: sync.color
              }}>
                <MSym name={sync.icon} size={12} color={sync.color} fill={1} />
                {sync.chip}
              </span>
            </>
          )}
        </div>
      </div>

      {/* Overflow trigger */}
      <button
        ref={btnRef}
        aria-label="More actions"
        aria-haspopup="menu"
        aria-expanded={menuOpen}
        onClick={e => { e.stopPropagation(); menuOpen ? onCloseMenu() : onOpenMenu(); }}
        style={{
          width: 36, height: 36, borderRadius: 10,
          background: menuOpen ? 'rgba(255,255,255,0.08)' : 'transparent',
          border: 'none', cursor: 'pointer',
          color: menuOpen ? EX.ink : EX.inkMute,
          display: 'grid', placeItems: 'center',
          transition: 'background 0.15s ease, color 0.15s ease'
        }}>
        <MSym name="more_vert" size={20} />
      </button>

      {/* Popover menu — conditional items per (hasEmail, syncState) */}
      {menuOpen && (
        <div
          ref={menuRef}
          role="menu"
          style={{
            position: 'absolute',
            top: 'calc(100% + 6px)',
            right: 8,
            minWidth: 200,
            background: EX.surfaceHi,
            border: `1px solid ${EX.outlineHi}`,
            borderRadius: 12,
            padding: 6,
            boxShadow: '0 8px 28px rgba(0,0,0,0.55), 0 2px 6px rgba(0,0,0,0.35)',
            zIndex: 10,
            animation: 'hopplyMenuIn 0.14s ease-out',
            transformOrigin: 'top right'
          }}>
          {/* Resend: only if user has email AND there's a cloud copy to resend */}
          <MenuItem icon="mail"       label="Resend email"    onClick={doAction('resend')}   hidden={!item.hasEmail || !isInCloud} />
          {/* Share: only if file is on this device */}
          <MenuItem icon="ios_share"  label="Share file"      onClick={doAction('share')}    hidden={!isOnDevice} />
          {/* Save to device: only if file is NOT on this device (cloud-only) */}
          <MenuItem icon="download"   label="Save to device"  onClick={doAction('download')} hidden={isOnDevice}  />
          <div style={{ height: 1, background: EX.outline, margin: '6px 4px' }} />
          <MenuItem icon="delete"     label="Delete export"   onClick={doAction('delete')}   destructive />
        </div>
      )}

      <style>{`
        @keyframes hopplyMenuIn {
          from { opacity: 0; transform: scale(0.96) translateY(-4px); }
          to   { opacity: 1; transform: scale(1) translateY(0); }
        }
      `}</style>
    </div>
  );
}

// ─── MenuItem ───────────────────────────────────────────────────────────
function MenuItem({ icon, label, onClick, destructive, hidden }) {
  if (hidden) return null;
  const color = destructive ? EX.err : EX.ink;
  return (
    <button
      role="menuitem"
      onClick={onClick}
      style={{
        width: '100%',
        display: 'flex', alignItems: 'center', gap: 12,
        padding: '10px 12px',
        background: 'transparent',
        border: 'none', borderRadius: 8,
        cursor: 'pointer',
        color,
        fontFamily: F.body, fontSize: 14, fontWeight: 500,
        textAlign: 'left',
        transition: 'background 0.12s ease'
      }}
      onMouseOver={e => e.currentTarget.style.background = destructive ? 'rgba(255,107,107,0.10)' : 'rgba(255,255,255,0.06)'}
      onMouseOut={e => e.currentTarget.style.background = 'transparent'}>
      <MSym name={icon} size={18} color={color} />
      {label}
    </button>
  );
}

// Expose for the host HTML
Object.assign(window, { ExportHistoryScreen, HISTORY_ITEMS, SYNC_STATES, EX, F });
