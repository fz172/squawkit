# Handoff: WingsLog — Maintenance Logs Screen & Log Detail Bottom Sheet

## Overview
This package covers the redesigned **Maintenance Logs** screen and the new **Log Detail bottom sheet** for the WingsLog aviation logbook app. It includes the log list view (with search and type filter) and a detail sheet that opens when a log entry is tapped, following the same IA pattern as the existing Maintenance Task bottom sheet.

## About the Design Files
The files in this bundle are **HTML design references** — high-fidelity prototypes showing intended look, typography, layout, and behavior. They are **not production code to ship directly**. Your task is to recreate these designs in the WingsLog app's existing environment (React Native, SwiftUI, or whatever the production stack uses), using its established component patterns, navigation primitives, and libraries.

Open `Maintenance Logs Screen.html` in a browser to explore the full interactive prototype. It shows 5 phone frames side by side:
- **Light · List** — the log list in light mode
- **Light · Detail** — the log detail sheet open (light mode)
- **Dark · List** — the log list in dark mode
- **Dark · Detail** — the log detail sheet with linked tasks (dark mode)
- **Dark · No Tasks** — the log detail sheet with no linked tasks (dark mode)

Tap any log card to open the sheet. Tap the dimmed background to dismiss.

## Fidelity
**High-fidelity.** Colors, typography, spacing, radius, and interactions are all specified to pixel level. Recreate the UI exactly as shown using the codebase's existing component library and design tokens where they match; use the explicit values below where they don't.

---

## Screens / Views

### 1. Maintenance Logs List

**Purpose:** Shows all maintenance log entries for an aircraft, filterable by component type.

**Layout:**
- Full-screen scroll view, `background: #FAFAFA` (light) / `#0E0E10` (dark)
- Top bar: 48px height, back chevron left, settings gear right
- Tab bar below top bar: 3 equal tabs — Overview / Tasks / **Logs** (active)
- Search row: 12px padding all sides, search field (flex 1) + filter icon button (40×40px), 10px gap
- Filter chip row (visible only when filters active): 16px horizontal padding, 8px gap, wrapping
- Entry count label: uppercase, 11px, 0.7px letter-spacing, `onSurfaceVariant` color
- Log card list: 16px horizontal padding, 12px gap between cards, 100px bottom padding (FAB clearance)
- FAB: fixed bottom-right, 32px from bottom, 16px from right, 52px height, 16px border-radius

**Search field:**
- Height: 40px, border-radius: 10px
- Background: `surfaceContainer`, border: `1px solid outlineVariant`
- Padding: `0 12px`, 8px gap between icon and placeholder
- Placeholder: "Search logs…", 15px, `onSurfaceVariant`

**Filter button:**
- 40×40px, border-radius: 10px
- Inactive: `surfaceContainer` bg, `outlineVariant` border
- Active: `primaryContainer` bg, `primary` border, icon in `primary` color

**Active filter chips:**
- Background: `primaryContainer`, border: `1px solid primary`
- Color: `onPrimaryContainer`, 12px bold, 12px border-radius, 4px 10px padding
- Trailing × icon to dismiss

**FAB:**
- Background: `primary`, color: white
- Label: "+ Add Log", 15px/600, system font
- Shadow (light): `0 4px 14px rgba(26,95,174,0.35)`
- Shadow (dark): `0 4px 18px rgba(0,0,0,0.5)`

---

### 2. Log Card

**Purpose:** Summary row in the list. Tapping opens the Log Detail sheet.

**Layout (flex column, 10px gap):**
1. Top row: TypeBadge (left) | tach hrs in JetBrains Mono 12px + chevron (right)
2. Description text: 14px body, `onSurface`, 20px line-height
3. Hairline divider: 1px, `rgba(0,0,0,0.07)` light / `rgba(255,255,255,0.07)` dark
4. Footer row: date in JetBrains Mono 12px (left) | task count in `primary` + tech name in `onSurfaceVariant` (right)

**Card container:**
- Background: `surfaceContainer`
- Border: `1px solid outlineVariant`
- Border-radius: 12px
- Padding: `16px 18px`
- Press state: background shifts to `#EAEAF0` (light) / `#28282C` (dark), transition 0.12s

**TypeBadge:**
- Uppercase, 10px, 700 weight, 0.6px letter-spacing
- Border-radius: 4px, padding: `3px 8px`
- Color schemes by type:

| Type      | Light bg   | Light color | Dark bg  | Dark color |
|-----------|------------|-------------|----------|------------|
| ENGINE    | `#D5E3FF`  | `#001849`   | `#0D2547`| `#A7C8FF`  |
| AIRFRAME  | `#E3F2E8`  | `#1B4D2B`   | `#0D2C18`| `#81C784`  |
| AVIONICS  | `#FFDFA6`  | `#4A3000`   | `#2C1F00`| `#FFBA4E`  |
| PROPELLER | `#EDE7F6`  | `#311B6B`   | `#1E0F3A`| `#CE93D8`  |

---

### 3. Log Detail Bottom Sheet

**Purpose:** Full detail view for a single log entry. Slides up from the bottom; background dims and is non-interactive while sheet is open. Tapping dimmed area dismisses.

**Container:**
- Border-radius: `22px 22px 0 0`
- Background: `#FFFFFF` (light) / `#1C1C1E` (dark)
- Shadow (light): `0 -4px 32px rgba(0,0,0,0.14)`
- Shadow (dark): `0 -6px 40px rgba(0,0,0,0.7)`
- Bottom padding: 36px

**Internal layout (top → bottom), horizontal padding 22px:**

1. **Handle bar** — centered, 36×4px, border-radius 2px, `outlineVariant`, 14px top padding, 20px bottom margin

2. **Header row** — TypeBadge (left) + "Edit Log" button (right, `primary`, 15px/600)

3. **Hero metric** — context-aware time value:
   - ENGINE log → "Engine Time"
   - AIRFRAME / AVIONICS → "Airframe Time"
   - PROPELLER → "Propeller Time"
   - Label: 11px/600, uppercase, 0.9px tracking, `onSurfaceVariant`, 6px below margin
   - Value: JetBrains Mono, 40px/700, `primary` color, `-0.5px` letter-spacing
   - Unit "hrs": body font, 16px/500, `onSurfaceVariant`, 6px left margin

4. **Description** — 14px body, `onSurfaceVariant`, 21px line-height. Followed by a hairline divider. 24px bottom padding before divider.

5. **"Affected Maintenance Tasks" section:**
   - Section header: Space Grotesk 14px/700, `onSurface`, 12px below margin
   - **With tasks:** List of task rows (see below)
   - **Empty state:** Muted container with italic "No tasks linked to this entry" in `onSurfaceVariant`

   **Task row:**
   - Background: `rgba(255,255,255,0.05)` dark / `surfaceContainer` light
   - Border: `1px solid outlineVariant`, border-radius: 10px, padding `11px 14px`
   - Left: checkmark icon (14×14) + task name (14px/500, `onSurface`)
   - Right: "→ Tasks tab" annotation pill + trailing chevron
   - Annotation pill: 11px/500, `primary` color, `primaryContainer` bg (light) / `rgba(167,200,255,0.12)` bg (dark), `4px` radius, `2px 7px` padding
   - **Behavior note:** Tapping a task row navigates to the Tasks tab and opens that task's detail bottom sheet.

6. **Footer row** — technician name (13px body, `onSurfaceVariant`) left, date (JetBrains Mono 12px/500, `onSurfaceVariant`) right. 16px top padding, hairline top border.

---

## Interactions & Behavior

| Trigger | Behavior |
|---|---|
| Tap log card | Opens Log Detail bottom sheet; background dims to `rgba(0,0,0,0.3)` |
| Tap dimmed background | Dismisses sheet |
| Tap "Edit Log" | Opens the log edit form (not in scope of this handoff) |
| Tap task row in sheet | Navigate to Tasks tab, open that task's bottom sheet |
| Tap filter button | Opens filter bottom sheet (handle + type checkboxes + Done) |
| Tap active filter chip × | Removes that filter |

---

## Design Tokens

### Colors

| Token              | Light      | Dark       |
|--------------------|------------|------------|
| `primary`          | `#1A5FAE`  | `#A7C8FF`  |
| `primaryContainer` | `#D5E3FF`  | `#004785`  |
| `onPrimaryContainer`| `#001849` | `#D5E3FF`  |
| `background`       | `#FAFAFA`  | `#0E0E10`  |
| `surfaceContainer` | `#F2F2F7`  | `#1C1C1E`  |
| `onSurface`        | `#1C1C1E`  | `#E5E5EA`  |
| `onSurfaceVariant` | `#636366`  | `#8E8E93`  |
| `outline`          | `#C6C6C8`  | `#48484A`  |
| `outlineVariant`   | `#E0E0E5`  | `#2C2C2E`  |

### Typography

| Role     | Font           | Usage |
|----------|----------------|-------|
| Headline | Space Grotesk  | Section headers, sheet title area |
| Data     | JetBrains Mono | Dates, tach values, numeric data |
| Body     | system-ui / -apple-system | All other text |

### Spacing & Shape

| Token        | Value  |
|--------------|--------|
| Card radius  | 12px   |
| Sheet radius | 22px   |
| Button radius| 16px   |
| Badge radius | 4px    |
| Task row radius | 10px |
| Card padding | 16px 18px |
| Sheet h-padding | 22px |

---

## Assets
- **Space Grotesk** (Medium 500, SemiBold 600, Bold 700) — included in `/fonts/`
- **JetBrains Mono** (Medium 500, Bold 700) — included in `/fonts/`
- No image assets required for this screen

## Files
| File | Description |
|------|-------------|
| `Maintenance Logs Screen.html` | Full interactive prototype — open in browser |
| `Theme.js` | WingsLog design token definitions (`WL_THEME`) |
| `ios-frame.jsx` | iOS device frame component used in prototype |
| `fonts/` | Space Grotesk + JetBrains Mono font files |
