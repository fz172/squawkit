// Hopply — Export logs flow (Setup, Ready, History)
// Design notes:
// - Dark surfaces match the rest of the app (dashboard / logs).
// - Material Symbols Outlined for iconography (loaded via Google Fonts in host HTML).
// - Section labels: ALL CAPS, primary-blue, 11px tracked — matches existing app pattern.
// - Tail numbers always rendered in JetBrains Mono — per design system.
// - No emoji.

const { useState, useEffect, useMemo, useRef } = React;

// ─── Tokens ─────────────────────────────────────────────────────────────
const EX = {
  bg: '#000000',
  surface: '#161618',
  surfaceHi: '#1F1F22',
  outline: 'rgba(255,255,255,0.08)',
  outlineHi: 'rgba(255,255,255,0.14)',
  primary: '#A7C8FF',
  primaryInk: '#0A2050',
  primaryDim: '#5FA3FF',
  ink: '#FFFFFF',
  inkMute: 'rgba(255,255,255,0.62)',
  inkDim: 'rgba(255,255,255,0.4)',
  ok: '#81C784',
  warn: '#FFCA28',
  err: '#FF6B6B'
};
const F = {
  headline: "'Space Grotesk', system-ui, sans-serif",
  data: "'JetBrains Mono', 'Courier New', monospace",
  body: "system-ui, -apple-system, sans-serif"
};

// Material Symbols — single source of truth.
function MSym({ name, size = 24, weight = 400, fill = 0, color = 'currentColor', style }) {
  return (
    <span className="material-symbols-outlined" style={{
      fontSize: size, color, lineHeight: 1,
      fontVariationSettings: `'FILL' ${fill}, 'wght' ${weight}, 'GRAD' 0, 'opsz' ${size}`,
      userSelect: 'none', flexShrink: 0,
      ...style
    }}>{name}</span>);

}

// ─── Common: Top app bar ────────────────────────────────────────────────
function TopBar({ title, onBack, trailing }) {
  return (
    <div style={{
      position: 'sticky', top: 0, zIndex: 4,
      background: EX.bg,
      padding: '60px 20px 14px 8px',
      display: 'flex', alignItems: 'center', gap: 4
    }}>
      <button onClick={onBack} aria-label="Back" style={{
        width: 44, height: 44, borderRadius: 999, background: 'transparent',
        border: 'none', cursor: 'pointer', color: EX.ink,
        display: 'grid', placeItems: 'center'
      }}>
        <MSym name="arrow_back" size={24} />
      </button>
      <h1 style={{
        flex: 1, fontFamily: F.headline, fontWeight: 700,
        fontSize: 26, lineHeight: '30px', letterSpacing: '-0.4px',
        color: EX.ink, margin: 0
      }}>{title}</h1>
      {trailing}
    </div>);

}

function SectionLabel({ children, action }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between',
      marginBottom: 10, paddingInline: 2
    }}>
      <div style={{
        fontFamily: F.body, fontSize: 11, fontWeight: 700,
        letterSpacing: '1.2px', textTransform: 'uppercase',
        color: EX.primary
      }}>{children}</div>
      {action}
    </div>);

}

// ─── Aircraft data ──────────────────────────────────────────────────────
const FLEET = [
{ tail: 'N2098U', model: 'SoroSuub N-1 Scout', logs: 8, last: 'Mar 02' },
{ tail: 'N532SL', model: 'Sling TSi',          logs: 12, last: 'Apr 14' },
{ tail: 'N123AA', model: 'Cessna 172SP',       logs: 5, last: 'Feb 18' }];

const USER_EMAIL = 'fanzhang172@gmail.com';


// Approx file size by formats (Set | array) and selection size.
// Everything ships as a ZIP — the formats picks the reports inside; attachments
// are always bundled once and dominate the payload.
function estimateSize(formats, logCount) {
  const perLog = (fmt) => fmt === 'PDF' ? 0.18 : fmt === 'XLSX' ? 0.06 : 0.04; // MB
  const attachPerLog = 0.55; // photos / pdfs / receipts, included once
  const base = 0.2;
  let reportTotal = 0;
  const set = formats instanceof Set ? formats : new Set(formats || []);
  for (const f of set) reportTotal += perLog(f);
  const n = base + (reportTotal + attachPerLog) * logCount;
  return n < 1 ? `${(n * 1024).toFixed(0)} KB` : `${n.toFixed(1)} MB`;
}

// Canonical display order; converts Set/array to ordered array.
const FORMAT_ORDER = ['PDF', 'CSV', 'XLSX'];
function orderFormats(input) {
  const set = input instanceof Set ? input : new Set(input || []);
  return FORMAT_ORDER.filter((f) => set.has(f));
}
function formatsJoin(arr) {
  if (!arr || arr.length === 0) return '—';
  if (arr.length === 1) return arr[0];
  if (arr.length === 2) return `${arr[0]} + ${arr[1]}`;
  return `${arr.slice(0, -1).join(', ')} + ${arr[arr.length - 1]}`;
}

// Material Symbols icon name for a single report format.
function formatIcon(format) {
  return format === 'PDF' ? 'picture_as_pdf' :
  format === 'XLSX' ? 'table_view' :
  'description'; // CSV
}

// Friendly file/title generators.
const fmtDate = (d) => `${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')}/${d.getFullYear()}`;
const monthDay = (d) => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

function rangeLabel(mode, custom) {
  if (mode === 'all') return 'All time';
  if (mode === '30') return 'Last 30 days';
  if (mode === '12') return 'Last 12 months';
  if (mode === 'custom' && custom) return `${monthDay(custom.start)} – ${monthDay(custom.end)}, ${custom.end.getFullYear()}`;
  return 'Custom';
}

// ─── SCREEN 1: Setup ────────────────────────────────────────────────────
function ExportSetupScreen({
  fleet, selection, setSelection,
  formats, toggleFormat,
  rangeMode, setRangeMode,
  customRange,
  onBack, onHistory, onExport
}) {
  const selectedCount = selection.size;
  const selectedLogs = fleet.
  filter((a) => selection.has(a.tail)).
  reduce((sum, a) => sum + a.logs, 0);

  // Date-range gives a coarse log-count multiplier (visual only).
  const rangeMul = rangeMode === '30' ? 0.18 : rangeMode === '12' ? 0.72 : 1;
  const logsInRange = Math.max(0, Math.round(selectedLogs * rangeMul));
  const size = estimateSize(formats, logsInRange);
  const orderedFormats = orderFormats(formats);
  const canExport = selectedCount > 0 && logsInRange > 0 && orderedFormats.length > 0;

  const toggle = (tail) => {
    const next = new Set(selection);
    if (next.has(tail)) next.delete(tail);else next.add(tail);
    setSelection(next);
  };
  const allSelected = selectedCount === fleet.length;

  return (
    <div style={{
      height: '100%', background: EX.bg, display: 'flex', flexDirection: 'column',
      overflow: 'hidden'
    }}>
      <TopBar
        title="Export logs"
        onBack={onBack}
        trailing={
        <button onClick={onHistory} aria-label="Export history" style={{
          width: 44, height: 44, borderRadius: 999, background: 'transparent',
          border: 'none', cursor: 'pointer', color: EX.ink,
          display: 'grid', placeItems: 'center'
        }}>
            <MSym name="history" size={24} />
          </button>
        } />
      

      {/* Scrollable form area */}
      <div style={{
        flex: 1, overflow: 'auto',
        padding: '4px 20px 24px'
      }}>

        {/* ── FORMATS (multi-select) ── */}
        <div style={{ marginBottom: 28 }}>
          <SectionLabel>Report formats</SectionLabel>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
            {[
            { id: 'PDF', icon: 'picture_as_pdf', sub: 'Print-ready' },
            { id: 'CSV', icon: 'description', sub: 'Plain text' },
            { id: 'XLSX', icon: 'table_view', sub: 'Spreadsheet' }].
            map((opt) => {
              const on = formats.has(opt.id);
              const isLastOne = on && formats.size === 1;
              return (
                <button
                  key={opt.id}
                  onClick={() => {if (!isLastOne) toggleFormat(opt.id);}}
                  aria-pressed={on}
                  title={isLastOne ? 'Pick at least one format' : undefined}
                  style={{
                    position: 'relative',
                    padding: '12px 8px 10px',
                    borderRadius: 14,
                    background: on ? 'rgba(167,200,255,0.10)' : 'transparent',
                    border: `1.5px solid ${on ? EX.primary : EX.outlineHi}`,
                    cursor: isLastOne ? 'not-allowed' : 'pointer',
                    display: 'flex', flexDirection: 'column',
                    alignItems: 'center', gap: 4,
                    transition: 'all 0.15s ease'
                  }}>
                  
                  {/* Multi-select check indicator */}
                  <div style={{
                    position: 'absolute', top: 7, right: 7,
                    width: 18, height: 18, borderRadius: 5,
                    background: on ? EX.primary : 'transparent',
                    border: on ? 'none' : `1.5px solid ${EX.outlineHi}`,
                    display: 'grid', placeItems: 'center',
                    transition: 'all 0.15s ease'
                  }}>
                    {on && <MSym name="check" size={13} color={EX.primaryInk} weight={700} />}
                  </div>
                  <MSym name={opt.icon} size={22} color={on ? EX.primary : EX.inkMute} fill={on ? 1 : 0} />
                  <div style={{
                    fontFamily: F.headline, fontWeight: 700, fontSize: 14,
                    color: on ? EX.primary : EX.ink, letterSpacing: '0.2px'
                  }}>{opt.id}</div>
                  <div style={{
                    fontFamily: F.body, fontSize: 11,
                    color: on ? EX.inkMute : EX.inkDim
                  }}>{opt.sub}</div>
                </button>);

            })}
          </div>
          {orderedFormats.length === 0 &&
            <div style={{
              marginTop: 10, paddingInline: 2,
              fontFamily: F.body, fontSize: 12.5,
              color: EX.warn
            }}>Pick at least one format.</div>
          }
        </div>

        {/* ── AIRCRAFT ── */}
        <div style={{ marginBottom: 28 }}>
          <SectionLabel
            action={fleet.length > 1 &&
            <button onClick={() => setSelection(allSelected ? new Set() : new Set(fleet.map((a) => a.tail)))} style={{
              background: 'none', border: 'none', cursor: 'pointer', padding: 0,
              fontFamily: F.body, fontSize: 13, fontWeight: 600,
              color: EX.primaryDim, letterSpacing: '-0.1px'
            }}>{allSelected ? 'Clear all' : 'Select all'}</button>
            }>
            Aircraft</SectionLabel>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {fleet.map((a) => {
              const on = selection.has(a.tail);
              return (
                <button key={a.tail} onClick={() => toggle(a.tail)} style={{
                  width: '100%', textAlign: 'left',
                  background: on ? 'rgba(167,200,255,0.06)' : EX.surface,
                  border: `1px solid ${on ? 'rgba(167,200,255,0.4)' : EX.outline}`,
                  borderRadius: 14, padding: '14px 16px',
                  display: 'flex', alignItems: 'center', gap: 14,
                  cursor: 'pointer',
                  transition: 'background 0.15s ease, border-color 0.15s ease'
                }}>
                  {/* Custom checkbox */}
                  <div style={{
                    width: 22, height: 22, borderRadius: 6,
                    background: on ? EX.primary : 'transparent',
                    border: on ? 'none' : `2px solid ${EX.outlineHi}`,
                    display: 'grid', placeItems: 'center',
                    transition: 'all 0.15s ease'
                  }}>
                    {on && <MSym name="check" size={16} color={EX.primaryInk} weight={700} />}
                  </div>

                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{
                      fontFamily: F.data, fontWeight: 700, fontSize: 15,
                      color: on ? EX.primary : EX.ink, letterSpacing: '0.4px',
                      marginBottom: 2
                    }}>{a.tail}</div>
                    <div style={{
                      fontFamily: F.body, fontSize: 13, color: EX.inkMute
                    }}>{a.model}</div>
                  </div>
                </button>);

            })}
          </div>
        </div>

        {/* ── DATE RANGE ── */}
        <div style={{ marginBottom: 12 }}>
          <SectionLabel>Date range</SectionLabel>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {[
            { id: 'all', label: 'All time' },
            { id: '12', label: 'Last 12 months' },
            { id: 'custom', label: 'Custom' }].
            map((opt) => {
              const on = rangeMode === opt.id;
              return (
                <button key={opt.id} onClick={() => setRangeMode(opt.id)} style={{
                  padding: '9px 14px',
                  borderRadius: 12,
                  background: on ? EX.primary : 'transparent',
                  border: `1.5px solid ${on ? EX.primary : EX.outlineHi}`,
                  color: on ? EX.primaryInk : EX.ink,
                  cursor: 'pointer',
                  fontFamily: F.body, fontSize: 13.5, fontWeight: 600,
                  letterSpacing: '-0.1px',
                  transition: 'all 0.15s ease'
                }}>
                  {opt.label}
                </button>);

            })}
          </div>

          {rangeMode === 'custom' && customRange &&
          <button style={{
            width: '100%', marginTop: 12,
            padding: '12px 16px',
            borderRadius: 12,
            background: EX.surface,
            border: `1px solid ${EX.outlineHi}`,
            cursor: 'pointer',
            display: 'flex', alignItems: 'center', gap: 12,
            textAlign: 'left'
          }}>
              <MSym name="event" size={20} color={EX.primary} />
              <div style={{ flex: 1 }}>
                <div style={{
                fontFamily: F.body, fontSize: 11, fontWeight: 600,
                letterSpacing: '0.6px', textTransform: 'uppercase',
                color: EX.inkDim, marginBottom: 2
              }}>Range</div>
                <div style={{
                fontFamily: F.data, fontWeight: 500, fontSize: 14,
                color: EX.ink, letterSpacing: '0.2px'
              }}>
                  {fmtDate(customRange.start)} <span style={{ color: EX.inkDim, padding: '0 4px' }}>→</span> {fmtDate(customRange.end)}
                </div>
              </div>
              <MSym name="edit_calendar" size={20} color={EX.inkMute} />
            </button>
          }
        </div>
      </div>

      {/* Sticky footer: compact summary + primary action */}
      <div style={{
        background: EX.bg,
        padding: '12px 20px 28px',
        borderTop: `1px solid ${EX.outline}`,
        display: 'flex', flexDirection: 'column', gap: 10
      }}>
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          fontFamily: F.body, fontSize: 12.5, color: EX.inkMute,
          paddingInline: 2
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <MSym name="flight" size={14} color={EX.inkDim} />
            <span><strong style={{ color: EX.ink, fontWeight: 600 }}>{selectedCount}</strong> aircraft</span>
            <span style={{ color: EX.inkDim }}>·</span>
            <span>{rangeLabel(rangeMode, customRange)}</span>
            <span style={{ color: EX.inkDim }}>·</span>
            <span>~{size}</span>
          </div>
        </div>

        <button onClick={canExport ? onExport : undefined} disabled={!canExport} style={{
          width: '100%', height: 54, borderRadius: 16,
          background: canExport ? EX.primary : 'rgba(167,200,255,0.18)',
          color: canExport ? EX.primaryInk : EX.inkDim,
          border: 'none', cursor: canExport ? 'pointer' : 'not-allowed',
          fontFamily: F.headline, fontSize: 16, fontWeight: 700,
          letterSpacing: '0.2px',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
          transition: 'background 0.15s ease'
        }}>
          <MSym name="mail" size={20} weight={600} />
          Email export
        </button>

        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          fontFamily: F.body, fontSize: 11.5, color: EX.inkDim,
          paddingInline: 2
        }}>
          <span>Sent to</span>
          <span style={{ fontFamily: F.data, color: EX.inkMute }}>{USER_EMAIL}</span>
        </div>
      </div>
    </div>);

}

// ─── SCREEN 2: Ready ────────────────────────────────────────────────────
// ─── SCREEN 2: Result (status-aware: success or error variants) ───────
// Same shell across all states: hero icon + title + card + action stack.
// Only the tone, copy, and card body change.

const RESULT_TONES = {
  ok: { color: EX.ok, bg: 'rgba(129,199,132,0.15)', border: 'rgba(129,199,132,0.35)' },
  warn: { color: EX.warn, bg: 'rgba(255,202,40,0.13)', border: 'rgba(255,202,40,0.40)' },
  info: { color: EX.primary, bg: 'rgba(167,200,255,0.13)', border: 'rgba(167,200,255,0.35)' },
  error: { color: EX.err, bg: 'rgba(255,107,107,0.12)', border: 'rgba(255,107,107,0.40)' }
};

function ExportReadyScreen({
  status = 'success',
  fleet, selection, formats, rangeMode, customRange, size,
  onShare, onDone, onHistory, onBack,
  onRetry, onContinueAnyway, onOpenSettings, onManageStorage
}) {
  const [animateIn, setAnimateIn] = useState(false);
  useEffect(() => {setAnimateIn(true);}, []);

  const aircraftLabels = fleet.
  filter((a) => selection.has(a.tail)).
  map((a) => a.tail);
  const aircraftSummary = aircraftLabels.length === 0 ? '—' :
  aircraftLabels.length === 1 ? aircraftLabels[0] :
  aircraftLabels.length <= 2 ? aircraftLabels.join(', ') :
  `${aircraftLabels[0]} + ${aircraftLabels.length - 1} more`;

  const today = new Date(2026, 4, 22);
  const ymd = `${today.getFullYear()}${String(today.getMonth() + 1).padStart(2, '0')}${String(today.getDate()).padStart(2, '0')}`;
  const baseName = aircraftLabels.length === 1 ?
  `Hopply_Logs_${aircraftLabels[0]}_${ymd}` :
  `Hopply_Logs_Fleet_${ymd}`;
  const filename = `${baseName}.zip`;
  const orderedFormats = orderFormats(formats);

  // Variant: per-status content. Keep the shape the same so the shell renders
  // identically across states.
  const variant = (() => {
    switch (status) {
      case 'low-storage':return {
          tone: 'warn', icon: 'sd_card_alert',
          title: 'Not enough space',
          subtitle: 'This device needs 12 MB more free space to save the ZIP.',
          body: <ErrorDetailsCard text="Free up space in Settings › General › Storage, then try again. Photos and Mail attachments are usually the largest items." />,
          primary: { label: 'Manage storage', icon: 'settings', onClick: onManageStorage || onBack },
          secondary: [{ label: 'Back to setup', icon: 'tune', onClick: onBack }]
        };
      case 'partial-attachments':return {
          tone: 'warn', icon: 'cloud_off',
          title: 'Attachments incomplete',
          subtitle: '4 of 16 attachments couldn’t be downloaded from iCloud.',
          body: <ErrorDetailsCard text="Connect to Wi-Fi or check that iCloud Photos is signed in, then retry. You can export without them — log entries stay intact." />,
          primary: { label: 'Retry attachments', icon: 'refresh', onClick: onRetry || onBack },
          secondary: [
          { label: 'Export without them', icon: 'east', onClick: onContinueAnyway || onBack }]

        };
      case 'no-permission':return {
          tone: 'info', icon: 'lock', fillIcon: true,
          title: 'Permission needed',
          subtitle: 'Hopply needs access to Files to save the ZIP on this device.',
          body: <ErrorDetailsCard text="Open Settings › Hopply and enable Files access. Hopply only writes to your Downloads folder when you tap Share or Save." />,
          primary: { label: 'Open Settings', icon: 'open_in_new', onClick: onOpenSettings || onBack },
          secondary: [{ label: 'Not now', onClick: onBack, plain: true }]
        };
      case 'generic-error':return {
          tone: 'error', icon: 'error', fillIcon: true,
          title: 'Export failed',
          subtitle: 'Something went wrong while building the ZIP. Try again in a moment.',
          body: <ErrorDetailsCard text={<>If this keeps happening, contact   <span style={{ color: EX.ink, fontWeight: 600 }}>support@fanfly.dev</span> so we can look into it.<div style={{ marginTop: 10, fontFamily: F.data, fontSize: 12, color: EX.inkDim, letterSpacing: '0.4px' }}></div></>} />,
          primary: { label: 'Try again', icon: 'refresh', onClick: onRetry || onBack },
          secondary: [{ label: 'Back to setup', icon: 'tune', onClick: onBack }]
        };
      case 'success':
      default:return {
          tone: 'ok', icon: 'check',
          title: 'Export sent',
          subtitle: <>Secure download link emailed to <span style={{ fontFamily: F.data, color: EX.ink }}>{USER_EMAIL}</span></>,
          body: <ReadyReceiptCard
            filename={filename} size={size}
            orderedFormats={orderedFormats}
            aircraftSummary={aircraftSummary}
            rangeText={rangeLabel(rangeMode, customRange)} />,

          primary: { label: 'Done', onClick: onDone },
          secondary: [
          { label: 'View exports', icon: 'history', onClick: onHistory }]

        };
      case 'no-email':return {
          tone: 'ok', icon: 'check',
          title: 'Export ready',
          subtitle: <>Saved to <span style={{ color: EX.ink }}>Downloads · Hopply</span></>,
          body: <>
            <NoEmailNote />
            <div style={{ height: 10 }} />
            <ReadyReceiptCard
              filename={filename} size={size}
              orderedFormats={orderedFormats}
              aircraftSummary={aircraftSummary}
              rangeText={rangeLabel(rangeMode, customRange)} />
          </>,
          primary: { label: 'Share', icon: 'ios_share', onClick: onShare },
          secondary: [
          { label: 'View exports', icon: 'history', onClick: onHistory },
          { label: 'Done', onClick: onDone, plain: true }]
        };
    }
  })();

  const tone = RESULT_TONES[variant.tone];

  return (
    <div style={{
      height: '100%', background: EX.bg,
      display: 'flex', flexDirection: 'column'
    }}>
      <TopBar title="Export logs" onBack={onBack} />

      <div style={{
        flex: 1, overflow: 'auto',
        padding: '8px 20px 24px',
        display: 'flex', flexDirection: 'column'
      }}>

        {/* Hero */}
        <div style={{
          textAlign: 'center', marginTop: 20, marginBottom: 24,
          opacity: animateIn ? 1 : 0,
          transform: animateIn ? 'translateY(0)' : 'translateY(8px)',
          transition: 'opacity 0.4s ease, transform 0.5s cubic-bezier(.22,1,.36,1)'
        }}>
          <div style={{
            width: 72, height: 72, borderRadius: 999,
            background: tone.bg,
            border: `1.5px solid ${tone.border}`,
            display: 'grid', placeItems: 'center',
            margin: '0 auto 16px'
          }}>
            <MSym name={variant.icon} size={36} color={tone.color}
            weight={700} fill={variant.fillIcon ? 1 : 0} />
          </div>
          <h2 style={{
            fontFamily: F.headline, fontWeight: 700, fontSize: 28,
            letterSpacing: '-0.5px', color: EX.ink, margin: 0
          }}>{variant.title}</h2>
          <div style={{
            fontFamily: F.body, fontSize: 14, color: EX.inkMute,
            marginTop: 6, maxWidth: 320, marginInline: 'auto',
            lineHeight: '20px'
          }}>{variant.subtitle}</div>
        </div>

        {/* Variant body card */}
        <div style={{
          opacity: animateIn ? 1 : 0,
          transform: animateIn ? 'translateY(0)' : 'translateY(12px)',
          transition: 'opacity 0.5s ease 0.1s, transform 0.55s cubic-bezier(.22,1,.36,1) 0.1s'
        }}>{variant.body}</div>

        {/* Action stack */}
        <div style={{
          marginTop: 22, display: 'flex', flexDirection: 'column', gap: 10,
          opacity: animateIn ? 1 : 0,
          transform: animateIn ? 'translateY(0)' : 'translateY(12px)',
          transition: 'opacity 0.55s ease 0.18s, transform 0.6s cubic-bezier(.22,1,.36,1) 0.18s'
        }}>
          <button onClick={variant.primary.onClick} style={{
            width: '100%', height: 54, borderRadius: 16,
            background: EX.primary, color: EX.primaryInk,
            border: 'none', cursor: 'pointer',
            fontFamily: F.headline, fontSize: 16, fontWeight: 700,
            letterSpacing: '0.2px',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10
          }}>
            {variant.primary.icon && <MSym name={variant.primary.icon} size={20} weight={600} />}
            {variant.primary.label}
          </button>

          {variant.secondary && variant.secondary.length > 0 &&
          <div style={{ display: 'flex', gap: 10 }}>
              {variant.secondary.map((s, i) =>
            <button key={i} onClick={s.onClick} style={{
              flex: 1, height: 48, borderRadius: 14,
              background: 'transparent',
              color: s.plain ? EX.inkMute : EX.ink,
              border: s.plain ? 'none' : `1.5px solid ${EX.outlineHi}`,
              cursor: 'pointer',
              fontFamily: F.headline, fontSize: 14.5, fontWeight: 600,
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8
            }}>
                  {s.icon && <MSym name={s.icon} size={18} />}
                  {s.label}
                </button>
            )}
            </div>
          }
        </div>

        <div style={{ flex: 1 }} />
      </div>
    </div>);

}

// ─── Variant body cards ─────────────────────────────────────────────────

function ReadyReceiptCard({ filename, size, orderedFormats, aircraftSummary, rangeText }) {
  return (
    <div style={{
      background: EX.surface,
      border: `1px solid ${EX.outline}`,
      borderRadius: 16,
      padding: 18
    }}>
      {/* File row */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, paddingBottom: 14 }}>
        <div style={{
          width: 44, height: 44, borderRadius: 12,
          background: 'rgba(167,200,255,0.12)',
          display: 'grid', placeItems: 'center', flexShrink: 0
        }}>
          <MSym name="folder_zip" size={24} color={EX.primary} fill={1} />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            fontFamily: F.headline, fontWeight: 600, fontSize: 14.5,
            color: EX.ink, lineHeight: '20px',
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap'
          }}>{filename}</div>
          <div style={{
            fontFamily: F.body, fontSize: 12.5, color: EX.inkMute,
            marginTop: 2
          }}>{size} · ZIP containing {formatsJoin(orderedFormats)} + attachments</div>
        </div>
      </div>

      <div style={{ height: 1, background: EX.outline, marginInline: -18 }} />

      <div style={{ paddingTop: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <ReceiptRow icon="flight" label="Aircraft" value={aircraftSummary} mono />
        <ReceiptRow icon="date_range" label="Range" value={rangeText} />
        <ReceiptRow icon="attachment" label="Attachments" value="Included" />
      </div>
    </div>);

}

// Generic error details — used by every error state. Just a quiet card with text.
// Accepts a string or a React node for richer detail.
function ErrorDetailsCard({ text }) {
  return (
    <div style={{
      background: EX.surface,
      border: `1px solid ${EX.outline}`,
      borderRadius: 16,
      padding: 18,
      fontFamily: F.body, fontSize: 13.5, lineHeight: '20px',
      color: EX.inkMute
    }}>{text}</div>);

}

// Quiet inline note for the "no email on file" success path.
function NoEmailNote() {
  return (
    <div style={{
      background: 'rgba(167,200,255,0.08)',
      border: `1px solid rgba(167,200,255,0.22)`,
      borderRadius: 14,
      padding: '12px 14px',
      display: 'flex', alignItems: 'center', gap: 12
    }}>
      <MSym name="info" size={20} color={EX.primary} fill={1} />
      <div style={{
        flex: 1,
        fontFamily: F.body, fontSize: 13.5, lineHeight: '18px',
        color: EX.inkMute
      }}>
        <span style={{ color: EX.ink, fontWeight: 600 }}>No email on file.</span>{' '}
        Share manually below.
      </div>
    </div>
  );
}

function ReceiptRow({ icon, label, value, mono, valueColor }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12
    }}>
      <MSym name={icon} size={18} color={EX.inkDim} />
      <div style={{
        fontFamily: F.body, fontSize: 13, color: EX.inkMute, width: 110
      }}>{label}</div>
      <div style={{
        flex: 1, textAlign: 'right',
        fontFamily: mono ? F.data : F.body,
        fontSize: mono ? 13.5 : 13, fontWeight: 600,
        color: valueColor || EX.ink, letterSpacing: mono ? '0.3px' : 0,
        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap'
      }}>{value}</div>
    </div>);

}

// ─── SCREEN 2.5: Progress (preparing export) ─────────────────────────────
// Minimal: ZIP icon → title → step → progress → checklist → cancel.
// Stages are autoadvanced for the mock; in production this binds to backend events.
const PROGRESS_STAGES = [
  { id: 'collect',  label: 'Collecting aircraft data' },
  { id: 'generate', label: 'Generating reports'        },
  { id: 'compress', label: 'Compressing archive'       },
  { id: 'upload',   label: 'Uploading'                 },
  { id: 'email',    label: 'Sending email'             }
];

function ExportProgressScreen({ onBack, onCancel, onComplete }) {
  // Mock animation: tick through stages then call onComplete.
  const [stageIdx, setStageIdx] = useState(0);
  const [pct, setPct] = useState(0);

  useEffect(() => {
    const tick = setInterval(() => {
      setPct(p => {
        const next = p + 1.2;
        if (next >= 100) {
          clearInterval(tick);
          setTimeout(() => onComplete && onComplete(), 350);
          return 100;
        }
        // Advance stage on thresholds (20/40/60/80/100)
        const newStage = Math.min(PROGRESS_STAGES.length - 1, Math.floor(next / 20));
        setStageIdx(newStage);
        return next;
      });
    }, 60);
    return () => clearInterval(tick);
  }, [onComplete]);

  const currentStage = PROGRESS_STAGES[stageIdx];

  return (
    <div style={{
      height: '100%', background: EX.bg,
      display: 'flex', flexDirection: 'column'
    }}>
      <TopBar title="Export logs" onBack={onBack} />

      <div style={{
        flex: 1, overflow: 'hidden',
        padding: '8px 20px 24px',
        display: 'flex', flexDirection: 'column'
      }}>
        {/* Hero */}
        <div style={{ textAlign: 'center', marginTop: 24, marginBottom: 28 }}>
          <div style={{
            width: 72, height: 72, borderRadius: 999,
            background: 'rgba(167,200,255,0.13)',
            border: `1.5px solid rgba(167,200,255,0.35)`,
            display: 'grid', placeItems: 'center',
            margin: '0 auto 18px',
            position: 'relative'
          }}>
            <MSym name="folder_zip" size={32} color={EX.primary} fill={1} />
            {/* Subtle pulsing ring */}
            <div style={{
              position: 'absolute', inset: -6, borderRadius: 999,
              border: `1.5px solid ${EX.primary}`,
              opacity: 0.35,
              animation: 'hopplyPulse 1.6s ease-in-out infinite'
            }} />
          </div>
          <h2 style={{
            fontFamily: F.headline, fontWeight: 700, fontSize: 26,
            letterSpacing: '-0.5px', color: EX.ink, margin: 0
          }}>Preparing export</h2>
          <div style={{
            fontFamily: F.body, fontSize: 14, color: EX.inkMute,
            marginTop: 6, lineHeight: '20px'
          }}>{currentStage.label}…</div>
        </div>

        {/* Progress bar with inline % */}
        <div style={{ marginBottom: 28 }}>
          <div style={{
            height: 6, borderRadius: 999,
            background: 'rgba(255,255,255,0.06)',
            overflow: 'hidden'
          }}>
            <div style={{
              width: `${pct}%`, height: '100%',
              background: EX.primary,
              borderRadius: 999,
              transition: 'width 0.18s linear'
            }} />
          </div>
          <div style={{
            marginTop: 8,
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            fontFamily: F.data, fontSize: 12, color: EX.inkMute,
            letterSpacing: '0.4px'
          }}>
            <span>{Math.round(pct)}%</span>
            <span style={{ color: EX.inkDim }}>{stageIdx + 1} / {PROGRESS_STAGES.length}</span>
          </div>
        </div>

        {/* Checklist */}
        <div style={{
          background: EX.surface,
          border: `1px solid ${EX.outline}`,
          borderRadius: 14,
          padding: '14px 16px',
          display: 'flex', flexDirection: 'column', gap: 12
        }}>
          {PROGRESS_STAGES.map((s, i) => {
            const done = i < stageIdx;
            const active = i === stageIdx;
            return (
              <div key={s.id} style={{
                display: 'flex', alignItems: 'center', gap: 12,
                opacity: done || active ? 1 : 0.45
              }}>
                <div style={{
                  width: 18, height: 18, borderRadius: 999,
                  display: 'grid', placeItems: 'center', flexShrink: 0
                }}>
                  {done ? (
                    <MSym name="check_circle" size={18} color={EX.ok} fill={1} />
                  ) : active ? (
                    <div style={{
                      width: 14, height: 14, borderRadius: 999,
                      border: `2px solid ${EX.primary}`,
                      borderTopColor: 'transparent',
                      animation: 'hopplySpin 0.8s linear infinite'
                    }} />
                  ) : (
                    <div style={{
                      width: 12, height: 12, borderRadius: 999,
                      border: `1.5px solid ${EX.outlineHi}`
                    }} />
                  )}
                </div>
                <div style={{
                  fontFamily: F.body, fontSize: 14,
                  fontWeight: active ? 600 : 500,
                  color: active ? EX.ink : (done ? EX.inkMute : EX.inkDim)
                }}>{s.label}</div>
              </div>
            );
          })}
        </div>

        <div style={{ flex: 1 }} />

        {/* Cancel */}
        <button onClick={onCancel} style={{
          width: '100%', height: 50, borderRadius: 14,
          background: 'transparent',
          border: `1.5px solid ${EX.outlineHi}`,
          color: EX.ink, cursor: 'pointer',
          fontFamily: F.headline, fontSize: 14.5, fontWeight: 600
        }}>Cancel</button>
      </div>

      <style>{`
        @keyframes hopplySpin { to { transform: rotate(360deg); } }
        @keyframes hopplyPulse {
          0%, 100% { transform: scale(1); opacity: 0.35; }
          50%      { transform: scale(1.08); opacity: 0; }
        }
      `}</style>
    </div>
  );
}

// ─── SCREEN 3: History ──────────────────────────────────────────────────
// Every export is a ZIP; `formats` is the list of report document types inside.
// `hasEmail` — user has email on file (so Resend is even possible to offer)
// `syncState` — 'synced' (device + cloud), 'cloud' (remote only), 'local' (device only)
const HISTORY_ITEMS = [
{
  id: 'h1', formats: ['PDF', 'CSV', 'XLSX'], aircraft: ['N2098U', 'N532SL'],
  rangeLabel: 'All time', logs: 20, size: '4.9 MB',
  when: 'Today, 9:57',
  hasEmail: true, syncState: 'synced'
},
{
  id: 'h2', formats: ['PDF', 'XLSX'], aircraft: ['N532SL'],
  rangeLabel: 'Last 12 months', logs: 8, size: '3.1 MB',
  when: 'May 14',
  hasEmail: true, syncState: 'cloud'
},
{
  id: 'h3', formats: ['PDF'], aircraft: ['N2098U'],
  rangeLabel: 'Mar 1 – Apr 30', logs: 6, size: '2.4 MB',
  when: 'May 02',
  hasEmail: false, syncState: 'local'
},
{
  id: 'h4', formats: ['CSV'], aircraft: ['N532SL'],
  rangeLabel: 'Annual 2025', logs: 12, size: '7.1 MB',
  when: 'Jan 04',
  hasEmail: false, syncState: 'cloud'
}];

// Sync-state visual + label spec.
const SYNC_STATES = {
  synced: { chip: null, icon: null }, // default — no badge
  cloud:  { chip: 'In cloud',  icon: 'cloud',         color: '#9FB6D9', tint: 'rgba(159,182,217,0.10)' },
  local:  { chip: 'On device', icon: 'phone_iphone',  color: '#C9A961', tint: 'rgba(201,169,97,0.10)'  }
};


function ExportHistoryScreen({ onBack, onNew, empty }) {
  // Default to the first card's menu open so the menu mock is visible on landing.
  const [openMenuId, setOpenMenuId] = useState('h1');

  if (empty) {
    return (
      <div style={{ height: '100%', background: EX.bg, display: 'flex', flexDirection: 'column' }}>
        <TopBar title="Export history" onBack={onBack} />
        <div style={{
          flex: 1, display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center',
          textAlign: 'center', padding: '0 32px'
        }}>
          <MSym name="inbox" size={56} color={EX.inkDim} />
          <h3 style={{
            fontFamily: F.headline, fontWeight: 700, fontSize: 22,
            color: EX.ink, margin: '14px 0 6px'
          }}>No exports yet</h3>
          <div style={{
            fontFamily: F.body, fontSize: 14, color: EX.inkMute,
            lineHeight: '20px', maxWidth: 280, marginBottom: 22
          }}>
            Generate a printable PDF or spreadsheet of your maintenance logs to share with your mechanic, IA, or insurance.
          </div>
          <button onClick={onNew} style={{
            padding: '12px 22px', borderRadius: 14,
            background: EX.primary, color: EX.primaryInk,
            border: 'none', cursor: 'pointer',
            fontFamily: F.headline, fontSize: 14.5, fontWeight: 700
          }}>New export</button>
        </div>
      </div>);

  }

  return (
    <div style={{ height: '100%', background: EX.bg, display: 'flex', flexDirection: 'column' }}>
      <TopBar
        title="Export history"
        onBack={onBack} />
      

      <div style={{
        flex: 1, overflow: 'auto',
        padding: '4px 16px 24px'
      }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, position: 'relative' }}>
          {HISTORY_ITEMS.map((item) =>
          <HistoryCard
            key={item.id}
            item={item}
            menuOpen={openMenuId === item.id}
            onOpenMenu={() => setOpenMenuId(item.id)}
            onCloseMenu={() => setOpenMenuId(null)}
          />
          )}
        </div>
      </div>
    </div>);

}

function HistoryCard({ item, menuOpen, onOpenMenu, onCloseMenu }) {
  const aircraftText = item.aircraft.length === 1 ?
  item.aircraft[0] :
  `${item.aircraft[0]} +${item.aircraft.length - 1}`;
  const fmts = orderFormats(item.formats);
  const sync = SYNC_STATES[item.syncState] || SYNC_STATES.synced;
  const isOnDevice = item.syncState === 'synced' || item.syncState === 'local';
  const isInCloud  = item.syncState === 'synced' || item.syncState === 'cloud';
  const menuRef = useRef(null);
  const btnRef = useRef(null);

  // Click-outside dismiss
  useEffect(() => {
    if (!menuOpen) return;
    const onDown = (e) => {
      if (menuRef.current?.contains(e.target)) return;
      if (btnRef.current?.contains(e.target)) return;
      onCloseMenu && onCloseMenu();
    };
    const onKey = (e) => { if (e.key === 'Escape') onCloseMenu && onCloseMenu(); };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [menuOpen, onCloseMenu]);

  const doAction = (label) => () => {
    console.log(`[history] ${label} → ${item.id}`);
    onCloseMenu && onCloseMenu();
  };

  return (
    <div style={{
      background: EX.surface,
      border: `1px solid ${menuOpen ? EX.outlineHi : EX.outline}`,
      borderRadius: 14,
      padding: 14,
      display: 'flex', alignItems: 'center', gap: 12,
      position: 'relative',
      zIndex: menuOpen ? 5 : 1,
      transition: 'border-color 0.15s ease'
    }}>
      {/* ZIP icon */}
      <div style={{
        width: 44, height: 44, borderRadius: 12,
        background: 'rgba(167,200,255,0.12)',
        display: 'grid', placeItems: 'center', flexShrink: 0
      }}>
        <MSym name="folder_zip" size={22} color={EX.primary} fill={1} />
      </div>

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontFamily: F.data, fontSize: 14, fontWeight: 700,
          color: EX.ink, letterSpacing: '0.3px', marginBottom: 3
        }}>{aircraftText}</div>
        <div style={{
          fontFamily: F.body, fontSize: 12.5, color: EX.inkMute,
          lineHeight: '17px',
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap'
        }}>
          {formatsJoin(fmts)} <span style={{ color: EX.inkDim }}>·</span> {item.rangeLabel}
        </div>
        <div style={{
          marginTop: 3,
          fontFamily: F.body, fontSize: 11.5, color: EX.inkDim,
          display: 'flex', alignItems: 'center', gap: 6,
          flexWrap: 'wrap'
        }}>
          <span>{item.when}</span>
          <span style={{ opacity: 0.6 }}>·</span>
          <span>{item.size}</span>
          {sync.chip && (
            <>
              <span style={{ opacity: 0.6 }}>·</span>
              <span style={{
                display: 'inline-flex', alignItems: 'center', gap: 4,
                color: sync.color
              }}>
                <MSym name={sync.icon} size={12} color={sync.color} fill={1} />
                {sync.chip}
              </span>
            </>
          )}
        </div>
      </div>

      {/* Overflow trigger */}
      <button
        ref={btnRef}
        aria-label="More actions"
        aria-haspopup="menu"
        aria-expanded={menuOpen}
        onClick={(e) => { e.stopPropagation(); menuOpen ? onCloseMenu() : onOpenMenu(); }}
        style={{
          width: 36, height: 36, borderRadius: 10,
          background: menuOpen ? 'rgba(255,255,255,0.08)' : 'transparent',
          border: 'none', cursor: 'pointer',
          color: menuOpen ? EX.ink : EX.inkMute,
          display: 'grid', placeItems: 'center',
          transition: 'background 0.15s ease, color 0.15s ease'
        }}>
        <MSym name="more_vert" size={20} />
      </button>

      {/* Popover menu */}
      {menuOpen && (
        <div
          ref={menuRef}
          role="menu"
          style={{
            position: 'absolute',
            top: 'calc(100% + 6px)',
            right: 8,
            minWidth: 200,
            background: EX.surfaceHi,
            border: `1px solid ${EX.outlineHi}`,
            borderRadius: 12,
            padding: 6,
            boxShadow: '0 8px 28px rgba(0,0,0,0.55), 0 2px 6px rgba(0,0,0,0.35)',
            zIndex: 10,
            animation: 'hopplyMenuIn 0.14s ease-out',
            transformOrigin: 'top right'
          }}>
          <MenuItem icon="mail" label="Resend email" onClick={doAction('resend')} hidden={!item.hasEmail || !isInCloud} />
          <MenuItem icon="ios_share" label="Share file" onClick={doAction('share')} hidden={!isOnDevice} />
          <MenuItem icon="download" label="Save to device" onClick={doAction('download')} hidden={isOnDevice} />
          <div style={{ height: 1, background: EX.outline, margin: '6px 4px' }} />
          <MenuItem icon="delete" label="Delete export" onClick={doAction('delete')} destructive />
        </div>
      )}

      <style>{`
        @keyframes hopplyMenuIn {
          from { opacity: 0; transform: scale(0.96) translateY(-4px); }
          to   { opacity: 1; transform: scale(1) translateY(0); }
        }
      `}</style>
    </div>);

}

function MenuItem({ icon, label, onClick, destructive, hidden }) {
  if (hidden) return null;
  const color = destructive ? EX.err : EX.ink;
  return (
    <button
      role="menuitem"
      onClick={onClick}
      style={{
        width: '100%',
        display: 'flex', alignItems: 'center', gap: 12,
        padding: '10px 12px',
        background: 'transparent',
        border: 'none', borderRadius: 8,
        cursor: 'pointer',
        color,
        fontFamily: F.body, fontSize: 14, fontWeight: 500,
        textAlign: 'left',
        transition: 'background 0.12s ease'
      }}
      onMouseOver={(e) => e.currentTarget.style.background = destructive ? 'rgba(255,107,107,0.10)' : 'rgba(255,255,255,0.06)'}
      onMouseOut={(e) => e.currentTarget.style.background = 'transparent'}>
      <MSym name={icon} size={18} color={color} />
      {label}
    </button>
  );
}

// ─── Exports ────────────────────────────────────────────────────────────
Object.assign(window, {
  ExportSetupScreen, ExportProgressScreen, ExportReadyScreen, ExportHistoryScreen,
  FLEET, USER_EMAIL, estimateSize, rangeLabel, monthDay, orderFormats, formatsJoin, FORMAT_ORDER,
  EX, F
});